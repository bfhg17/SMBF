/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica;

/**
 *
 * @author Evans.C
 */
public class Solicitud_de_materiales{
    float nSolicitud;
    String codigo;
    String cantidad;
    String unidad;
    String descripcion;
    String solicitante;
    String justificacion;
    String departamento;
    
        public float getNSolicitud() {
        return nSolicitud;
    }

    public void setNSolicitud(float nSolicitud ) {
        this.nSolicitud = nSolicitud;
    }
    
     public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
    
     public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }
    
     public String getUnidad() {
        return unidad;
    }
     
    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }
    
     public String getDescripcion() {
        return descripcion;
    }
      public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

   
       public String getSolicitane() {
        return solicitante;
    }

    public void setSolicitante(String solicitante) {
        this.solicitante = solicitante;
    }
    
       public String getJustificacion() {
        return justificacion;
    }

    public void setJustificacion(String justificacion) {
        this.justificacion= justificacion;
    }
    
        public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento= departamento;
    }
}
   

   


    