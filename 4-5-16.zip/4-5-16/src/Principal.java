
import DB.JavaConnection;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.event.KeyEvent;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Set;
import java.util.logging.*;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import static org.eclipse.persistence.jpa.jpql.utility.CollectionTools.array;
import static org.eclipse.persistence.jpa.jpql.utility.CollectionTools.array;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bradley
 */
public class Principal extends javax.swing.JFrame {
    int x,y; 
    DateFormat dateFormat;
    Calendar cal = Calendar.getInstance();
    
String fecha=cal.get(cal.DATE)+"/"+cal.get(cal.MONTH)+"/"+cal.get(cal.YEAR);

    /**
     * Creates new form NewJFrame
     */
    DefaultTableModel modeloTablaNuevoMaterial;
    DefaultTableModel modeloTablaBusquedaEspecifica;
    DefaultTableModel modeloTablaRegistrar;
    DefaultTableModel modeloTablaCrearOrden;
    DefaultTableModel ESOrden_Compra;
    DefaultTableModel EsSoli_M;
     DefaultTableModel ModifOrden;
    

    
    DB.JavaConnection con = new DB.JavaConnection();
    //JavaConnection con= new JavaConnection(); //probando
    int codProve=0;
    int numOrden = 0;
    Connection cn= con.connect();
    
    int totalOrden;//variables que calculan el total de la orden de compra
    int totalOrdenBusca;
    int totalOrdenModif;
    

    
    //VARIABLES INTRODUCIDAS POR MOISES
    public static final String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
    String datosUsuario[]=new String[3]; //arreglo para conseguir la informacion del usuario para meter la solicitud
     int numSoli=0; // guarda el numero de solicitud cuando alguien da clic en buscar en el modulo de modificar
     
     
     DefaultTableModel modeloTablaCrearSolicitud;
    DefaultTableModel modeloTablaModificarSolicitud;
    //VARIABLES INTRODUCIDAS POR MOISES
    
    
    public Principal() {
        this.dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        modeloTablaNuevoMaterial = new DefaultTableModel(null,getColumnasInventario());
        modeloTablaBusquedaEspecifica = new DefaultTableModel(null,getColumnasInventario());
        modeloTablaRegistrar = new DefaultTableModel(null,getColumnasInventario());
        modeloTablaCrearOrden=new DefaultTableModel(null,getColumnasOrden());
        ESOrden_Compra = new DefaultTableModel(null,getColumnasESOrden_Compra());
         EsSoli_M = new DefaultTableModel(null,getColumnasEsSoli_M());
         ModifOrden = new DefaultTableModel(null, getColumnasModifOrden());
         modeloTablaCrearSolicitud=new DefaultTableModel(null,getColumnasSolicitud()){

 @Override
 public boolean isCellEditable(int row, int column)
 {
     return false;
 }
  };
        modeloTablaModificarSolicitud=new DefaultTableModel(null, getColumnasModificarSolicitud()){

 @Override
 public boolean isCellEditable(int row, int column)
 {
     return false;
 }
  };
        setUndecorated(true);
        initComponents();
       setExtendedState(MAXIMIZED_BOTH);
       llenarComboBox();
        setFilasInventario();//Inicializacion de los dos metodos para las tablas
        setLocationRelativeTo(null);
       this.getContentPane().setBackground(Color.white);
       
       jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
  @Override
  public void mousePressed(java.awt.event.MouseEvent e) {
    if (e.getClickCount() == 2) {
      JTable target = (JTable)e.getSource();
      int row = target.getSelectedRow();
      int column = target.getSelectedColumn();
      if(column==0){
      codAntiguo.setText(target.getValueAt(row,column).toString());
      }
    }
  }
});
    }

    void buscaInventario(int codMaterial, String nomMaterial){
    DefaultTableModel modeloC = new DefaultTableModel(); // es el modlo del filtro del inventario
    modeloC.addColumn("id_material");
    modeloC.addColumn("nombre");
    modeloC.addColumn("categoria");
    modeloC.addColumn("tipoUnidad");
    modeloC.addColumn("cantidadMinima");
    modeloC.addColumn("cantidadStock");
    modeloC.addColumn("ubicación");
    tablaNuevoMaterial.setModel(modeloC);
    String sqlc = "";
    //"SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion FROM material WHERE id_material ='"+jtxtCodigos2.getText()+"'";    
        if (codMaterial != 0 && nomMaterial.equals("")){
        sqlc = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion FROM material WHERE id_material ='"+codMaterial+"'";    
        }else {
        sqlc = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion FROM material WHERE nombre ='"+nomMaterial+"'";    
        }
        String []datos = new String [7];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sqlc);
            while(rs.next()){
                datos[0]=rs.getString(1);
                datos[1]=rs.getString(2);
                datos[2]=rs.getString(3);
                datos[3]=rs.getString(4);
                datos[4]=rs.getString(5);
                datos[5]=rs.getString(6);
                datos[6]=rs.getString(7);
                   modeloC.addRow(datos);
                
            }
           
        }
        catch (SQLException ex) {
            System.out.println(ex.getMessage());
        JOptionPane.showMessageDialog(null, "Error desconocido"); 
        }
     tablaNuevoMaterial.setModel(modeloC);
    }
    //
    
   
    
    
    //---------------------------------------------Metodos introducidos por Moises
    
     void validaTabla(TableModelEvent e){
    
         if (e.getType() == TableModelEvent.UPDATE) {
        
             TableModel modelo = ((TableModel) (e.getSource()));
            int fila = e.getFirstRow();
            int columna = e.getColumn();
             
              if (columna == 6) {
                int cantidad = Integer.parseInt(modelo.getValueAt(fila,
                        3).toString());
       
                int cantidadR = Integer.parseInt(modelo.getValueAt(fila,
                        6).toString());
                if(cantidad<cantidadR){
                System.out.println("Cantidad invalida");
                JOptionPane.showMessageDialog(null,"Cantidad inválida"); 
                modelo.setValueAt("", fila, columna);
                    
                }
                  
            }
             
         }
    }
    
    void guardarEsSoli_M(int x,String cod){  // Descuenta los materiales de la soli en el inven
    
    String sql2="UPDATE solicitud_materiales SET estado='Entregado' WHERE numero_Solicitud="+jComboBox7.getSelectedItem();
        try{
        
        PreparedStatement us2 = con.connect().prepareStatement(sql2);
      us2.executeUpdate();
      System.out.println("Exito");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
        JOptionPane.showMessageDialog(this, "ERROR AL INTRODUCIR LOS DATOS");
        System.out.println(sql2);}
        
        
        
        String sql3="UPDATE material SET cantidadStock=cantidadStock "+"-"+x+" WHERE id_material="+cod;
        try{
        
        PreparedStatement us2 = con.connect().prepareStatement(sql3);
      us2.executeUpdate();
      System.out.println("Exito");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
        JOptionPane.showMessageDialog(this, "ERROR AL INTRODUCIR LOS DATOS");
        System.out.println(sql2);}
   
    
    }
    
     private String[] getColumnasEsSoli_M(){//DESCONTAR LOS MATERIALES DE LA SOLI
    
    String columna[] = new String[]{"Código","Tipo de Unidad","Descripción","Cantidad"};
    return columna;
    }
    
    
    public static String now() {
Calendar cal = Calendar.getInstance();
SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
return sdf.format(cal.getTime());

}//este metodo es para meter la fecha en la base de datos

      private String[] getColumnasOrden(){//b
    
    String columna[] = new String[]{"Fecha","Codigo Proveedor","Cantidad","Tipo de Unidad","Codigo Material","Descripcion","Número Orden","Precio unitario ¢","Precio Total ¢"};

    return columna;
    }
      
     private String[] getColumnasModifOrden(){
     String columna [] = new String[]{"Fecha", "Cod. Proveeedor", "Cantidad", "Cod. Material", "Número Orden", "Precio Unitario ¢", "Precio Total ¢"};  
             
   
    return columna;
    
    
         
     }
      
       private String[] getColumnasESOrden_Compra(){//b
    
    String columna[] = new String[]{"Codigo","Tipo de Unidad","Descripcion","Cantidad","Ubicación","Cantidad Registrada","Cantidad Recibida"};
    return columna;
    }
    
    private String[] getColumnasModificarSolicitud(){
    String columna[] = new String[]{"ID Material","Cantidad","Nombre"};
    return columna;
    }//son las columnas para el table model de modificar solicitud
    
    private String[] getColumnasSolicitud(){//b
    
    String columna[] = new String[]{"Codigo","Cantidad","Tipo de Unidad","Descripcion","Solicitante"};
    return columna;
    }
    
    
    
    void obtener_informacion_usuario(){ //este metodo es para obtener los datos del usuario del login
        
        try{
         String sql = "SELECT nombre,id_usuario,departamento FROM  usuario WHERE nickname_login='"+campoUsuario.getText()+"'";
         System.out.println(sql);   
         PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
             while(res.next()){
                
      String nombre=res.getString("nombre");

      String idUsuario=res.getString("id_usuario");

      String departamento=res.getString("departamento");

      datosUsuario[0]=nombre;
     datosUsuario[1]=idUsuario;
     datosUsuario[2]=departamento;
      
     }
            
            
 }
        
        catch(SQLException e){
        System.out.println("Error Mysql");
        }
    }
    
     void guardarESOrden(int x,int y,String cod,String numOrden){
    
    String sql2="UPDATE detalle_orden SET cantidad_registrada="+y+" WHERE numero_orden="+numOrden+" AND id_material="+cod;
        try{
        
        PreparedStatement us2 = con.connect().prepareStatement(sql2);
      us2.executeUpdate();
      System.out.println("Exito");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
        JOptionPane.showMessageDialog(this, "ERROR AL INTRODUCIR LOS DATOS");
        System.out.println(sql2);}
        
        
        
        String sql3="UPDATE material SET cantidadStock="+x+"+cantidadStock WHERE id_material="+cod;
        try{
        
        PreparedStatement us2 = con.connect().prepareStatement(sql3);
      us2.executeUpdate();
      System.out.println("Exito");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
        JOptionPane.showMessageDialog(this, "ERROR AL INTRODUCIR LOS DATOS");
        System.out.println(sql2);}
        
        
        
    }
    
    String obtenerTipo(String Cod){
        String tipo="ERROR";
        String sql="SELECT tipoUnidad from material WHERE id_material ="+Cod;
        try{
        
        
        PreparedStatement us = con.connect().prepareStatement(sql);
        ResultSet rs=us.executeQuery();
        
     while(rs.next()){
      tipo=rs.getString("tipoUnidad");
     }
        return tipo;
       
    }  catch(SQLException e){
        System.out.println("Error Mysql");
     System.out.println(sql);
        }
        return tipo;
    }
    
    void busca(){
        try{
            String sql = "SELECT nombre FROM usuario WHERE id_usuario="+ jtxIDUSU.getText();
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
           if(res.next()){
           jtxtId3.setText(res.getString("nombre"));
           }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
}

void buscaModificar(){
 try{
            String sql = "SELECT nombre,nickname_login,contraseña,departamento FROM usuario WHERE id_usuario="+ jtxtId2.getText();
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
           if(res.next()){
           jTextNombreMod.setText(res.getString("nombre"));
           jtxtUser4.setText(res.getString("nickname_login"));
        
           }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
}
  
    void actualizarUsuario(){
    try {//String pas = Arrays.toString(jtxtContraseña3.getPassword());
    String pas =  String.valueOf(jtxtContraseña3.getPassword());
        PreparedStatement pst = cn.prepareStatement("UPDATE usuario SET nickname_login='"+jtxtUser4.getText()+"',contraseña='"+pas+"',departamento='"+jtstdepa2.getText()+"',tipo_usua='"+jComboBox13.getSelectedItem()+"' WHERE id_usuario='"+jtxtId2.getText()+"'");
        pst.executeUpdate();
       System.out.println("Datos actualizados correctamente");
       JOptionPane.showMessageDialog(null, "Datos Actualizados Correctamente");
       jtxtUser4.setText("");
       jtstdepa2.setText("");
       jtxtId2.setText("");
       jtxtContraseña3.setText("");
       jTextNombreMod.setText("");
    } catch (Exception e) {
        System.out.print(e.getMessage());
    }
    
    }
    String ObtenerDescripcion(String cod){
        
    String codigo="";
    
        String sql="SELECT nombre from material WHERE id_material ="+cod;
        try{
        
        
        PreparedStatement us = con.connect().prepareStatement(sql);
        ResultSet rs=us.executeQuery();
        
     while(rs.next()){
     codigo=rs.getString("nombre");
     }
  return codigo;
  
    }  catch(SQLException e){
        System.out.println("Error Mysql");
     System.out.println(sql);
        }
    return codigo;
    }
    
    void ActualizarNuevoMaterial(){
    try{
        String jcm = jtxtCodigoM.getText();
        String jdm = jtxtDescripM.getText();
        String jcbcm = jComboBoxCategoriaM.getSelectedItem().toString();
        String jtcm = jTextCantMinM.getText();
        String jcbtm = jComboBoxTipoM.getSelectedItem().toString();
        String sql=" UPDATE material SET `nombre` = '"+ jdm +"',`categoria` = '"+ jcbcm +"',`cantidadMinima` = '"+ jtcm +"',`tipoUnidad` = '"+ jcbtm+"' WHERE `material`.`id_material` = '"+jcm+"'";

        PreparedStatement us = con.connect().prepareStatement(sql);
       
            int n = us.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null, "Material Actualizado");
            }
    }  catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
    private void llenarComboBox(){
         this.jComboBox7.removeAllItems();
     try{
            String sql = "SELECT `numero_Solicitud` FROM solicitud_materiales WHERE `estado`= 'pendiente'" ;
          //  SELECT numero_Solicitud FROM solicitud_materiales WHERE estado=pendiente 
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            while(res.next()){
            this.jComboBox7.addItem(res.getString("numero_Solicitud"));
            }
            
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
     void LimpiarActualizarMaterial(){
    jtxtCodigoM.setText("");
    jtxtDescripM.setText("");
    jTextCantMinM.setText("");
    jComboBoxCategoriaM.setSelectedItem("Acueducto");
    jComboBoxTipoM.setSelectedItem("Bolsa");
    }
    
    
    int insertarSolicitud(String justificacion){//este metodo es para insertar en la tabla solicitud_materiales
int num=-1;
ResultSet rs;
    String sql="";
    Statement stmt=null;
    
      sql="INSERT INTO solicitud_materiales (fecha,nombre_solic,id_solicitante,depart_proceso"
                + ",justificacion,estado) VALUES('"+now()+"','"+datosUsuario[0]+"','"+datosUsuario[1]+"','"+datosUsuario[2]
                +"','"+justificacion+"','pendiente')";
      try{
        stmt = con.connect().createStatement();
      
        stmt.executeUpdate(sql,Statement.RETURN_GENERATED_KEYS);

        rs = stmt.getGeneratedKeys();
        
if (rs.next()){
    num=rs.getInt(1);
}
System.out.println(num);
 }
catch(SQLException e){ 
    System.out.println("Error Mysql");
    System.out.println(sql);}
    
    return num;
    }
     
    
    
    void enviarSolic(String[] datos,int numero_solicitud){//este metodo es para insertar en la tabla detalle_solicitud

            String sql2="INSERT INTO detalle_solicitud(numero_solicitud,cantidad,id_material)"
                + "values("+numero_solicitud+","+datos[1]+","+datos[0]+")";
            System.out.println(sql2);
        try{
        
        PreparedStatement us2 = con.connect().prepareStatement(sql2);
      us2.executeUpdate();
      System.out.println("Exito");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
        JOptionPane.showMessageDialog(this, "Ha introducido un material invalido");
        System.out.println(sql2);}
    
    }
     
    //---------------------------------------------------------------------------------Metodos introducidos por Moises
    
    private String[] getColumnasInventario(){//b
    
    String columna[] = new String[]{"ID","Nombre","Categoría","Tipo de Unidad","Cantidad Mínima","Cantidad en Stock","Ubicación","Última Fecha de Registro"};
    return columna;
    }
    
    private void setFilasInventario(){//b
    
        try{  
       
      
            String sql = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion,fecha FROM material WHERE estado = 1";
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
            try (ResultSet res = us.executeQuery()) {
                Object datos[]=new Object[8];     
                while(res.next()){
                    for(int i = 0; i < 8 ; i++){
                        datos[i] = res.getObject(i + 1);
                         
                    }
                    modeloTablaNuevoMaterial.addRow(datos);
                }
            }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
    
     private void setFilasInventarioSelected(String c){//b
    
         if("General".equals(c)){
         setFilasInventario();
         }else{
        try{  
       
            String sql = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion , fecha FROM material WHERE estado = 1 and categoria = '"+c+"'";
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
            try (ResultSet res = us.executeQuery()) {
                Object datos[]=new Object[8];     
                while(res.next()){
                    for(int i = 0; i < 8 ; i++){
                        datos[i] = res.getObject(i + 1);
                    }
                    modeloTablaNuevoMaterial.addRow(datos);
                }
            }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
        
        }
         tablaNuevoMaterial.setModel(modeloTablaNuevoMaterial);
    }
 
     public void limpiarTabla(JTable tabla){//b
        try {
            DefaultTableModel modelo=(DefaultTableModel) tabla.getModel();
            int filas=tabla.getRowCount();
            for (int i = 0;filas>i; i++) {
                modelo.removeRow(0);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al limpiar la tabla.");
        }
    }
     // METODOS PARA VALIDAR LETRAS O NUMEROS 
 void SoloNumeros(java.awt.event.KeyEvent evt){
    char c; 
//capturar el caracter digitado 
 c=evt.getKeyChar(); 
if(c<'0'|| c>'9') 
{ 
 evt.consume();
    }
         }    
    
  void SoloLetras(java.awt.event.KeyEvent evt){
char c; 
    c=evt.getKeyChar(); 
    if(!(c<'0'||c>'9')) 
evt.consume(); 
}

     
    void LimpiarRegistroMaterial(){
    jtxtCodigos.setText("");
    jSpinnerCantidad.setText("");
    jTextCantMin.setText("");
    jTexUbicacionRegistro.setText(""); 
    jtxtDescription.setText("");
    }  
     // METODOS PARA NUEVO MATERIAL
    void LimpiarNuevoMaterial(){
    jtxtCodigo.setText("");
    jtxtDescrip.setText("");
    jTextCantMin.setText("");
    jComboBoxCategoria.setSelectedItem("Acueducto");
    jComboBoxTipo.setSelectedItem("Bolsa");
    }
    
    void LlenarNuevoMaterial(){
    try{
     String sql = "INSERT INTO material(id_material,nombre,categoria,tipoUnidad,cantidadMinima,fecha,cantidadStock)" + "values (?,?,?,?,?,?,0)";
            PreparedStatement us = con.connect().prepareStatement(sql);
            
            us.setString(1, jtxtCodigo.getText());
            us.setString(2, jtxtDescrip.getText());
            us.setString(3, jComboBoxCategoria.getSelectedItem().toString());
            us.setString(4, jComboBoxTipo.getSelectedItem().toString());
            us.setString(5, jTextCantMin.getText());//no esta retornando a la DB
            us.setString (6, now());
            int n = us.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null, "Datos Guardados");
            }
    }  catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
    
    //metodo para ingresar proveedores

void buscarProveedor(int codProve,String nombreProv ){
    DefaultTableModel buscaProveedor= new DefaultTableModel();
    buscaProveedor.addColumn("Cod. Proveedor");
    buscaProveedor.addColumn("Empresa");
    buscaProveedor.addColumn("Ced.Jurídica");
    buscaProveedor.addColumn("Nom. Contacto");
    buscaProveedor.addColumn("Apel. Contacto");
    buscaProveedor.addColumn("Teléfono");
    buscaProveedor.addColumn("Categoría");
    
    jTable21.setModel(buscaProveedor);
    
    String sql="";
    

       if(codProve != 0 && nombreProv.equals("")){
            sql="SELECT * FROM proveedores WHERE codigo_proveedor='"+codProve+"'";
    }else{
           sql="SELECT * FROM proveedores WHERE nombre_contacto='"+nombreProv+"'";
       }
    
    String []datos = new String [8];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0]=rs.getString(8);
                
                datos[1]=rs.getString(1);
                datos[2]=rs.getString(2);
                datos[3]=rs.getString(3);
                datos[4]=rs.getString(4);
                datos[5]=rs.getString(5);
                datos[6]=rs.getString(7);
                buscaProveedor.addRow(datos);
                jtxtDirecProveBuscar.setText(datos[7]=rs.getString(6));
            }
            jTable21.setModel(buscaProveedor);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    
void modificaProveedor(int codModProve,String nombreModProv ){
    
   
    
   
        String sql="";
       if(codModProve != 0 && nombreModProv.equals("")){
            sql="SELECT * FROM proveedores WHERE codigo_proveedor='"+codModProve+"'";
    }else{
           sql="SELECT * FROM proveedores WHERE nombre_contacto='"+nombreModProv+"'";
       }
    
    String []datos = new String [8];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
              

                jModifCodigo.setText(datos[0]=rs.getString(8));
                jModifEmpresa.setText(datos[1]=rs.getString(1));
                jModifCedJur.setText(datos[2]=rs.getString(2));
                jModifNom.setText(datos[3]=rs.getString(3));
                jModifApel.setText(datos[4]=rs.getString(4));

                jModifTel.setText(datos[5]=rs.getString(5));
                jDirecProveModif.setText(datos[6]=rs.getString(6));
                jModifCategoria.setText(datos[7]=rs.getString(7));
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    void LimpiarNuevoProveedor(){
        jTxtEmpresa01.setText("");
        jtxtCedJ01.setText("");
        jtxtNombre01.setText("");
        jtxtApe01.setText("");
        jtxtTele01.setText("");
        NProveedor01.setText("");
        jTextAreaDir.setText("");
        jTextCategoria.setText("");
    }
    void actualizarProveedor(){
       int codigoProve= Integer.parseInt(jModifCodigo.getText());
       
      // us = cn.prepareStatement("DELETE * from proveedores WHERE codigo_proveedor=" +codigo);
    try{
        PreparedStatement us = cn.prepareStatement("INSERT INTO proveedores(empresa,ced_juridica,nombre_contacto,apel_contacto,telefono,direccion,codigo_proveedor,categoria) VALUES (?,?,?,?,?,?,?,?)");
          
 
            
            us.setString(1, jModifEmpresa.getText());
            us.setString(2, jModifCedJur.getText());
            us.setString(3, jModifNom.getText());
            us.setString(4, jModifApel.getText());
            us.setString(5, jModifTel.getText());
            
            us.setString(6, jDirecProveModif.getText());  
            us.setInt(7, codigoProve);
            us.setString(8, jModifCategoria.getText());
            us.executeUpdate();
            

            JOptionPane.showMessageDialog(null, "Datos Guardados");
            
    }  catch(SQLException | HeadlessException e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Datos Ingresados Incorrectamente");
        }
    }
    //METODOS PARA REGISTRAR
    
    void BuscarCod(JTextField h,JTextField g){
     try{
            String sql = "SELECT nombre FROM material WHERE id_material="+ g.getText();
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
           if(res.next()){
           h.setText(res.getString("nombre"));
           }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
    
    
    void setFilasBuscarEspecifico(String c){
    
    try{  
       
            String sql = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion,fecha FROM material WHERE estado = 1 and id_material = '"+c+"'";
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
        try (ResultSet res = us.executeQuery()) {
            Object datos[]=new Object[8];
            while(res.next()){
                for(int i = 0; i < 8 ; i++){
                    datos[i] = res.getObject(i + 1);
                }
                modeloTablaBusquedaEspecifica.addRow(datos);
            }
        }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
        }
    
    
    }
    void setFilasRegistrar(String c){
    
    try{  
       
            String sql = "SELECT id_material,nombre,categoria,tipoUnidad,cantidadMinima,cantidadStock,ubicacion,fecha FROM material WHERE estado = 1 and id_material = '"+c+"'";
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
        try (ResultSet res = us.executeQuery()) {
            Object datos[]=new Object[8];
            while(res.next()){
                for(int i = 0; i < 8 ; i++){
                    datos[i] = res.getObject(i + 1);
                }
                modeloTablaRegistrar.addRow(datos);
            }
        }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
        }
    
    
    }
     private void mostrarDatosActM() {
       try{
            String sql = "SELECT  nombre , cantidadMinima, categoria, tipoUnidad FROM material WHERE id_material="+ jtxtCodigoM.getText();
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
           if(res.next()){
           jtxtDescripM.setText(res.getString("nombre"));
        jTextCantMinM.setText(res.getString("cantidadMinima"));
         jComboBoxCategoriaM.setSelectedItem(res.getString("categoria"));
         jComboBoxTipoM.setSelectedItem(res.getString("tipoUnidad"));
  
           }else {
           JOptionPane.showMessageDialog(null, "El material no Existe");
           jtxtCodigoM.setText("");
         jtxtDescripM.setText(" ");
        jTextCantMinM.setText(" ");
           }
    
        }   catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }    
    
     private void mostrarNombreM() {
       try{
            String sql = "SELECT  nombre ,ubicacion FROM material WHERE id_material="+ jtxtCodigos.getText();
            PreparedStatement us = con.connect().prepareStatement(sql);
            ResultSet res = us.executeQuery();
            
           if(res.next()){
           jtxtDescription.setText(res.getString("nombre"));
        jTexUbicacionRegistro.setText(res.getString("ubicacion"));
          jSpinnerCantidad.setText("");
           
           }
           else
           {
            JOptionPane.showMessageDialog(null, "El material no Existe");
           jtxtCodigos.setText("");
           jSpinnerCantidad.setText("");
            jtxtDescription.setText(" ");
        jTexUbicacionRegistro.setText(" ");
           
           }
    
        }   catch(SQLException e){
               System.out.println("Error Mysql");
     
        }
    }    

    void Registrar(){//b
    try{
        String hj = jtxtCodigos.getText();
        String ub = jTexUbicacionRegistro.getText();
        String sp =  jSpinnerCantidad.getText();
        String sql=" UPDATE material SET `ubicacion` = '"+ ub +"',`cantidadStock` =cantidadStock "+"+'"+ sp +"',`fecha` = '"+ fecha +"',`estado` = 1  WHERE `material`.`id_material` = '"+hj+"'";
        //System.out.println(cal.getTime());
        PreparedStatement us = con.connect().prepareStatement(sql);
       
            int n = us.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null, "Inventario Actualizado");
            }
    }  catch(SQLException e){
        System.out.println("Error Mysql");
     
        }
    }
    
    
     void deshabilitarUsuario(){
            try{
            String des=jTextArea4.getText();
            String op = jtxIDUSU.getText();
            String sql = "Update usuario SET `estado` = '0',`descripcion` = '"+ des +"' where `usuario`.`id_usuario` = '"+ op +"'";
            PreparedStatement us = con.connect().prepareStatement(sql);
            int n = us.executeUpdate();
            if(n>0){
             JOptionPane.showMessageDialog(null, "Usuario Deshabilitado Exitosamente");
            }
            }catch(SQLException e){ 
        
            }
    }
      void habilitarUsuario(){
            try{
            String des=jTextArea4.getText();
            String op = jtxIDUSU.getText();
            String sql = "Update usuario SET `estado` = '1',`descripcion` = '"+ des +"' where `usuario`.`id_usuario` = '"+ op +"'";
            PreparedStatement us = con.connect().prepareStatement(sql);
            int n = us.executeUpdate();
            if(n>0){
             JOptionPane.showMessageDialog(null, "Usuario Habilitado Exitosamente");
            }
            }catch(SQLException e){ 
        
            }
    }
        
    void CrearUsuario(){
        
        String pass =  String.valueOf(jtxtContraseña2.getPassword());
        String pass2 =  String.valueOf(jtxtRepetir2.getPassword());
    try{
            String sql = "INSERT INTO usuario(nombre,Apellido,nickname_login,contraseña,tipo_usua,departamento,estado,descripcion)" + "values (?,?,?,?,?,?,?,?)";
            PreparedStatement us = con.connect().prepareStatement(sql);
           
            if(pass.equals(pass2)){    
            us.setString(1, jtxtUser3.getText());
            us.setString(2, jtxtApel2.getText());
            us.setString(3, jtxtNick.getText());
            us.setString(4, pass);
            us.setString(5, jCBoxTipoUsua.getSelectedItem().toString());
            us.setString(6, jtxtDepa.getText());
            us.setString(7, "1");
            us.setString(8, jtxtDes2.getText());
            }
            else{
              JOptionPane.showMessageDialog(null, "Contraseña no Coincide , Intentelo de nuevo");
                 jtxtContraseña2.setText(""); 
                 jtxtRepetir2.setText("");
            }

            int n = us.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null, "Nuevo Usuario Creado");  
                 jtxtUser3.setText("");
                 jtxtApel2.setText("");
                 jtxtNick.setText("");
                 jtxtDepa.setText("");
                 jtxtDes2.setText("");
                 jtxtContraseña2.setText(""); 
                 jtxtRepetir2.setText("");
            }
            
    }  catch(SQLException e){
        System.out.println("Error Mysql");
        }
    
    
   
  //Reinicia los campos en bln
                 
    }
    
    
    
    boolean validarCodigo(String cod){
     try{
       
        String sql="SELECT id_material from material where id_material="+cod;
        PreparedStatement us = con.connect().prepareStatement(sql);
       ResultSet rs=us.executeQuery();
       if(!rs.isBeforeFirst()){
       return false;
       }
       else{
       return true;
       }
    }  catch(SQLException e){
        JOptionPane.showMessageDialog(this,"ERROR");
        //System.out.println("Error Mysql");
     return false;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator3 = new javax.swing.JSeparator();
        jSeparator11 = new javax.swing.JSeparator();
        jSeparator12 = new javax.swing.JSeparator();
        jSeparator13 = new javax.swing.JSeparator();
        jPopupMenu1 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        TaPa1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        TadP3 = new javax.swing.JTabbedPane();
        Pan3 = new javax.swing.JPanel();
        jComboBoxInventario = new javax.swing.JComboBox();
        jScrollPane10 = new javax.swing.JScrollPane();
        tablaNuevoMaterial = new javax.swing.JTable();
        lblCodigos = new javax.swing.JLabel();
        lblD = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jSeparator357 = new javax.swing.JSeparator();
        jLabel563 = new javax.swing.JLabel();
        jtxtDescription1 = new javax.swing.JTextField();
        jtxtCodigos2 = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        Pan18 = new javax.swing.JPanel();
        lblNumOrde = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        jTable11 = new javax.swing.JTable();
        jButton18 = new javax.swing.JButton();
        jLabel560 = new javax.swing.JLabel();
        jSeparator340 = new javax.swing.JSeparator();
        jButton20 = new javax.swing.JButton();
        jtxtOredesN = new javax.swing.JTextField();
        Pan22 = new javax.swing.JPanel();
        jComboBox7 = new javax.swing.JComboBox();
        lblSeleccionar = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        jTable12 = new javax.swing.JTable();
        jScrollPane13 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        lblJusticificacion = new javax.swing.JLabel();
        lblSolicitante = new javax.swing.JLabel();
        btnDescontar = new javax.swing.JButton();
        lblDepar = new javax.swing.JLabel();
        jtxtDepar = new javax.swing.JFormattedTextField();
        jtxtSolicitante = new javax.swing.JFormattedTextField();
        jLabel562 = new javax.swing.JLabel();
        jSeparator356 = new javax.swing.JSeparator();
        Pan10 = new javax.swing.JPanel();
        jSeparator21 = new javax.swing.JSeparator();
        jLabel40 = new javax.swing.JLabel();
        lblCodes = new javax.swing.JLabel();
        jtxtCodigos = new javax.swing.JFormattedTextField();
        jSpinnerCantidad = new javax.swing.JTextField();
        lblCanti = new javax.swing.JLabel();
        lblDe = new javax.swing.JLabel();
        jtxtDescription = new javax.swing.JFormattedTextField();
        jTexUbicacionRegistro = new javax.swing.JTextField();
        lblUbicaciones = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        Pan11 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        Pan12 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        jSeparator23 = new javax.swing.JSeparator();
        lblCod1 = new javax.swing.JLabel();
        jtxtCodigo = new javax.swing.JFormattedTextField();
        jtxtDescrip = new javax.swing.JFormattedTextField();
        lblDescr1 = new javax.swing.JLabel();
        lblCategorias1 = new javax.swing.JLabel();
        jComboBoxCategoria = new javax.swing.JComboBox();
        jTextCantMin = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jComboBoxTipo = new javax.swing.JComboBox();
        jButton14 = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jLabel46 = new javax.swing.JLabel();
        jSeparator22 = new javax.swing.JSeparator();
        lblCod2 = new javax.swing.JLabel();
        jtxtCodigoM = new javax.swing.JFormattedTextField();
        jtxtDescripM = new javax.swing.JFormattedTextField();
        lblDescr2 = new javax.swing.JLabel();
        lblCategorias2 = new javax.swing.JLabel();
        jComboBoxCategoriaM = new javax.swing.JComboBox();
        jTextCantMinM = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jComboBoxTipoM = new javax.swing.JComboBox();
        jButton19 = new javax.swing.JButton();
        jPanel23 = new javax.swing.JPanel();
        jTaPa9 = new javax.swing.JTabbedPane();
        Pan21 = new javax.swing.JPanel();
        lblSolicitudes = new javax.swing.JLabel();
        btnBusqueda = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel53 = new javax.swing.JLabel();
        jSeparator30 = new javax.swing.JSeparator();
        campoConsultaSolicitud = new javax.swing.JTextField();
        jPan19 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        btnCarga = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JSeparator();
        btnEnviar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        campoJustificacionCrearSolicitud = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        campoUsuario = new javax.swing.JTextField();
        jSpinner2 = new javax.swing.JSpinner();
        jSeparator29 = new javax.swing.JSeparator();
        jLabel52 = new javax.swing.JLabel();
        codCrearSolicitud = new javax.swing.JTextField();
        Pan20 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();
        lblNumero = new javax.swing.JLabel();
        btnBusca = new javax.swing.JButton();
        lblDescripcion = new javax.swing.JLabel();
        btnEnviaCambio = new javax.swing.JButton();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jSeparator28 = new javax.swing.JSeparator();
        jLabel51 = new javax.swing.JLabel();
        numSolicitudModificar = new javax.swing.JTextField();
        codAntiguo = new javax.swing.JTextField();
        codNuevo = new javax.swing.JTextField();
        cantidadNueva = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        TaP2 = new javax.swing.JTabbedPane();
        jPanel27 = new javax.swing.JPanel();
        Pan6 = new javax.swing.JPanel();
        btnCargar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnCrear = new javax.swing.JButton();
        lblNames = new javax.swing.JLabel();
        lblCedJu = new javax.swing.JLabel();
        lblContacto = new javax.swing.JLabel();
        jtxtCont = new javax.swing.JTextField();
        lblProveedor = new javax.swing.JLabel();
        lblCant = new javax.swing.JLabel();
        lblTiposU = new javax.swing.JLabel();
        lblDes = new javax.swing.JLabel();
        lblCode = new javax.swing.JLabel();
        lblUnitario = new javax.swing.JLabel();
        jComboBox5 = new javax.swing.JComboBox();
        lblNum = new javax.swing.JLabel();
        lblProductos = new javax.swing.JLabel();
        lblTotalOr = new javax.swing.JLabel();
        jtxtDesc = new javax.swing.JFormattedTextField();
        jLabel14 = new javax.swing.JLabel();
        jtxtApe = new javax.swing.JFormattedTextField();
        jtxtCedJ = new javax.swing.JFormattedTextField();
        jSpinner3 = new javax.swing.JSpinner();
        jLabel48 = new javax.swing.JLabel();
        jSeparator24 = new javax.swing.JSeparator();
        jSeparator25 = new javax.swing.JSeparator();
        jtxtCode = new javax.swing.JTextField();
        jtxtOrden = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jtxtPrecio = new javax.swing.JTextField();
        jtxtTotales = new javax.swing.JTextField();
        jTxtEmpresa = new javax.swing.JTextField();
        Pan7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        lblNumCompra = new javax.swing.JLabel();
        btnGuardar = new javax.swing.JButton();
        btnConsultar = new javax.swing.JButton();
        lblTotalOrde = new javax.swing.JLabel();
        lblEstate = new javax.swing.JLabel();
        jComboBox6 = new javax.swing.JComboBox();
        lblPro = new javax.swing.JLabel();
        lblNom = new javax.swing.JLabel();
        lblApe = new javax.swing.JLabel();
        lblCedJuri = new javax.swing.JLabel();
        jtxtCedula = new javax.swing.JFormattedTextField();
        lblCon = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jSeparator26 = new javax.swing.JSeparator();
        jtxtTotal = new javax.swing.JTextField();
        jtxtNumeroOrden = new javax.swing.JTextField();
        jtxtCodg = new javax.swing.JTextField();
        lblProductos1 = new javax.swing.JLabel();
        lblCode1 = new javax.swing.JLabel();
        lblTiposU1 = new javax.swing.JLabel();
        lblDes1 = new javax.swing.JLabel();
        lblCant1 = new javax.swing.JLabel();
        lblUnitario1 = new javax.swing.JLabel();
        jtxtCode1 = new javax.swing.JTextField();
        jComboBox8 = new javax.swing.JComboBox();
        jtxtPrecio1 = new javax.swing.JTextField();
        jSpinner4 = new javax.swing.JSpinner();
        jSeparator9 = new javax.swing.JSeparator();
        jSeparator14 = new javax.swing.JSeparator();
        jButton1 = new javax.swing.JButton();
        jtxtNombre = new javax.swing.JTextField();
        jtxtApellido = new javax.swing.JTextField();
        jtxtDesc1 = new javax.swing.JTextField();
        numAux = new javax.swing.JTextField();
        Pan8 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTableOrden = new javax.swing.JTable();
        lblOrdenCompra = new javax.swing.JLabel();
        btnBuscar = new javax.swing.JButton();
        lblTotalOrdenes = new javax.swing.JLabel();
        lblContact = new javax.swing.JLabel();
        lblCed = new javax.swing.JLabel();
        jtxtCed = new javax.swing.JFormattedTextField();
        jtxtName = new javax.swing.JFormattedTextField();
        lblNombres = new javax.swing.JLabel();
        jtxtLast = new javax.swing.JFormattedTextField();
        lblApellidos = new javax.swing.JLabel();
        lblProveedores = new javax.swing.JLabel();
        jLabel50 = new javax.swing.JLabel();
        jSeparator27 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jtxtCodgC = new javax.swing.JTextField();
        jtxtOrdenCOmpre = new javax.swing.JTextField();
        jTextTot = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        TadP6 = new javax.swing.JTabbedPane();
        Pan16 = new javax.swing.JPanel();
        lblUsers1 = new javax.swing.JLabel();
        jCBoxTipoUsua = new javax.swing.JComboBox();
        lblUser3 = new javax.swing.JLabel();
        jtxtUser3 = new javax.swing.JFormattedTextField();
        lblContraseña2 = new javax.swing.JLabel();
        jtxtContraseña2 = new javax.swing.JPasswordField();
        lblRepetir2 = new javax.swing.JLabel();
        jtxtRepetir2 = new javax.swing.JPasswordField();
        lblLastName2 = new javax.swing.JLabel();
        jtxtApel2 = new javax.swing.JFormattedTextField();
        lblPuesto2 = new javax.swing.JLabel();
        jtxtDepa = new javax.swing.JFormattedTextField();
        lblDescri2 = new javax.swing.JLabel();
        jtxtDes2 = new javax.swing.JFormattedTextField();
        btnCrearUsuario1 = new javax.swing.JButton();
        jLabel36 = new javax.swing.JLabel();
        lblUser4 = new javax.swing.JLabel();
        jtxtNick = new javax.swing.JFormattedTextField();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jSeparator17 = new javax.swing.JSeparator();
        Pan19 = new javax.swing.JPanel();
        jSeparator19 = new javax.swing.JSeparator();
        lblFiltro1 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jSeparator20 = new javax.swing.JSeparator();
        jtxIDUSU = new javax.swing.JFormattedTextField();
        lblId3 = new javax.swing.JLabel();
        lblUserName1 = new javax.swing.JLabel();
        jtxtId3 = new javax.swing.JFormattedTextField();
        jLabel43 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jButton7 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jButton5 = new javax.swing.JButton();
        jSeparator18 = new javax.swing.JSeparator();
        jLabel41 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        lblId2 = new javax.swing.JLabel();
        jtxtId2 = new javax.swing.JFormattedTextField();
        jTextNombreMod = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        lblUser5 = new javax.swing.JLabel();
        jtxtUser4 = new javax.swing.JFormattedTextField();
        jtxtContraseña3 = new javax.swing.JPasswordField();
        lblContraseña3 = new javax.swing.JLabel();
        lblPuesto3 = new javax.swing.JLabel();
        jtstdepa2 = new javax.swing.JFormattedTextField();
        jComboBox13 = new javax.swing.JComboBox();
        lblTipos2 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        TadP5 = new javax.swing.JTabbedPane();
        jPanel16 = new javax.swing.JPanel();
        TadP7 = new javax.swing.JTabbedPane();
        Pan14 = new javax.swing.JPanel();
        btnMostrar = new javax.swing.JButton();
        jScrollPane17 = new javax.swing.JScrollPane();
        jTable16 = new javax.swing.JTable();
        Pan24 = new javax.swing.JPanel();
        btnMuestra = new javax.swing.JButton();
        jScrollPane18 = new javax.swing.JScrollPane();
        jTable17 = new javax.swing.JTable();
        Pan25 = new javax.swing.JPanel();
        btnMuestras = new javax.swing.JButton();
        jScrollPane19 = new javax.swing.JScrollPane();
        jTable18 = new javax.swing.JTable();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jButton10 = new javax.swing.JButton();
        Pan17 = new javax.swing.JPanel();
        jScrollPane16 = new javax.swing.JScrollPane();
        jTable15 = new javax.swing.JTable();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel8 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane26 = new javax.swing.JScrollPane();
        jTable21 = new javax.swing.JTable();
        jBuscaNomProve = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane27 = new javax.swing.JScrollPane();
        jtxtDirecProveBuscar = new javax.swing.JTextArea();
        jLabel55 = new javax.swing.JLabel();
        jSeparator33 = new javax.swing.JSeparator();
        jBuscaCodProve = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        lblNames01 = new javax.swing.JLabel();
        lblCedJu01 = new javax.swing.JLabel();
        lblContacto01 = new javax.swing.JLabel();
        lblTel01 = new javax.swing.JLabel();
        lblDirection01 = new javax.swing.JLabel();
        jtxtTele01 = new javax.swing.JFormattedTextField();
        jTxtEmpresa01 = new javax.swing.JTextField();
        jtxtCedJ01 = new javax.swing.JFormattedTextField();
        jLabela15 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        jTextAreaDir = new javax.swing.JTextArea();
        jLabela10 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jtxtNombre01 = new javax.swing.JTextField();
        jtxtApe01 = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        jTextCategoria = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        jSeparator31 = new javax.swing.JSeparator();
        NProveedor01 = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jBotonBuscaMod = new javax.swing.JButton();
        jModifNomProve = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane28 = new javax.swing.JScrollPane();
        jDirecProveModif = new javax.swing.JTextArea();
        jButton8 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jModifNom = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        jModifApel = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jModifEmpresa = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jModifCategoria = new javax.swing.JTextField();
        jSeparator32 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jModifTel = new javax.swing.JFormattedTextField();
        jModifCedJur = new javax.swing.JFormattedTextField();
        jModifCodProve = new javax.swing.JTextField();
        jModifCodigo = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblBienvenido = new javax.swing.JLabel();
        nombreUsuario = new javax.swing.JLabel();
        btnCerrarSesion = new javax.swing.JButton();
        lblSan = new javax.swing.JLabel();
        lblHeredia = new javax.swing.JLabel();
        lbl2016 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        btnAyuda = new javax.swing.JButton();
        lblSistemaBodega = new javax.swing.JLabel();
        lblMunicipalidad = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        jLabel30 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jToggleButton1 = new javax.swing.JToggleButton();

        jPopupMenu1.setLabel("Menu");
        jPopupMenu1.setRequestFocusEnabled(false);

        jMenuItem1.setText("Editar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem1);

        jMenuItem2.setText("Eliminar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jPopupMenu1.add(jMenuItem2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Bodega Municipalidad de Flores");
        setBackground(new java.awt.Color(204, 204, 204));
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        getContentPane().setLayout(null);

        TaPa1.setBackground(new java.awt.Color(0, 51, 102));
        TaPa1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        TaPa1.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        TaPa1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TaPa1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        TaPa1.setOpaque(true);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.setLayout(new java.awt.BorderLayout());

        TadP3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        jComboBoxInventario.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxInventario.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "General", "Materiales", "Acueducto", "Limpieza", "Suministros de oficina", "Herramientas", "Material mínimo" }));
        jComboBoxInventario.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxInventarioItemStateChanged(evt);
            }
        });
        jComboBoxInventario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jComboBoxInventarioFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jComboBoxInventarioFocusLost(evt);
            }
        });
        jComboBoxInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxInventarioActionPerformed(evt);
            }
        });
        jComboBoxInventario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBoxInventarioKeyPressed(evt);
            }
        });

        tablaNuevoMaterial.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        tablaNuevoMaterial.setModel(modeloTablaNuevoMaterial);
        jScrollPane10.setViewportView(tablaNuevoMaterial);

        lblCodigos.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCodigos.setText("Código  ");

        lblD.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblD.setText("Nombre");

        jButton9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton9.setText("Buscar");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jLabel563.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel563.setText("Inventario General  ");

        jtxtCodigos2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigos2ActionPerformed(evt);
            }
        });
        jtxtCodigos2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCodigos2KeyTyped(evt);
            }
        });

        javax.swing.GroupLayout Pan3Layout = new javax.swing.GroupLayout(Pan3);
        Pan3.setLayout(Pan3Layout);
        Pan3Layout.setHorizontalGroup(
            Pan3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 930, Short.MAX_VALUE)
            .addGroup(Pan3Layout.createSequentialGroup()
                .addGroup(Pan3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan3Layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addComponent(jComboBoxInventario, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblD)
                        .addGap(18, 18, 18)
                        .addComponent(jtxtDescription1, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblCodigos)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtxtCodigos2, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan3Layout.createSequentialGroup()
                        .addGap(325, 325, 325)
                        .addComponent(jLabel563))
                    .addGroup(Pan3Layout.createSequentialGroup()
                        .addGap(251, 251, 251)
                        .addComponent(jSeparator357, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(92, Short.MAX_VALUE))
        );
        Pan3Layout.setVerticalGroup(
            Pan3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan3Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(jLabel563)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator357, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 67, Short.MAX_VALUE)
                .addGroup(Pan3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan3Layout.createSequentialGroup()
                        .addComponent(jComboBoxInventario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblD)
                        .addComponent(lblCodigos)
                        .addComponent(jButton9)
                        .addComponent(jtxtDescription1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jtxtCodigos2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(114, 114, 114))
        );

        jComboBoxInventario.getAccessibleContext().setAccessibleName("");

        TadP3.addTab("Inventario General", Pan3);

        jTabbedPane6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        lblNumOrde.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblNumOrde.setText("Número de orden");

        jTable11.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane11.setViewportView(jTable11);

        jButton18.setText("Registrar");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jLabel560.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel560.setText("Entrada de Materiales  Por Orden De Compra");

        jButton20.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton20.setText("Buscar");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        jtxtOredesN.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtOredesNKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout Pan18Layout = new javax.swing.GroupLayout(Pan18);
        Pan18.setLayout(Pan18Layout);
        Pan18Layout.setHorizontalGroup(
            Pan18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan18Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Pan18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.DEFAULT_SIZE, 905, Short.MAX_VALUE)
                    .addGroup(Pan18Layout.createSequentialGroup()
                        .addComponent(lblNumOrde)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jtxtOredesN, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan18Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(386, 386, 386))
            .addGroup(Pan18Layout.createSequentialGroup()
                .addGroup(Pan18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan18Layout.createSequentialGroup()
                        .addGap(166, 166, 166)
                        .addComponent(jSeparator340, javax.swing.GroupLayout.PREFERRED_SIZE, 504, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan18Layout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(jLabel560, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan18Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(255, Short.MAX_VALUE))
        );
        Pan18Layout.setVerticalGroup(
            Pan18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel560)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator340, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addGroup(Pan18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNumOrde)
                    .addComponent(jtxtOredesN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton20)
                .addGap(41, 41, 41)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(104, Short.MAX_VALUE))
        );

        jTabbedPane6.addTab("Con Orden de compra", Pan18);

        jComboBox7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBox7.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Solicitudes Pendientes" }));
        jComboBox7.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBox7ItemStateChanged(evt);
            }
        });

        lblSeleccionar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblSeleccionar.setText("Seleccionar solicitud");

        jTable12.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Tipo de Unidad", "Descripción", "Cantidad"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane12.setViewportView(jTable12);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane13.setViewportView(jTextArea1);

        lblJusticificacion.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblJusticificacion.setText("Justificación de la Solicitud ");

        lblSolicitante.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblSolicitante.setText("Solicitante");

        btnDescontar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btnDescontar.setText("Descontar del Inventario");
        btnDescontar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDescontarActionPerformed(evt);
            }
        });

        lblDepar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblDepar.setText("Departamento");

        jtxtDepar.setEditable(false);
        try {
            jtxtDepar.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("************")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtDepar.setToolTipText("Nombre del departamento.");
        jtxtDepar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtDeparKeyTyped(evt);
            }
        });

        jtxtSolicitante.setEditable(false);
        try {
            jtxtSolicitante.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*************")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtSolicitante.setToolTipText("Nombre del Solicitante.");
        jtxtSolicitante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtSolicitanteActionPerformed(evt);
            }
        });
        jtxtSolicitante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtSolicitanteKeyTyped(evt);
            }
        });

        jLabel562.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel562.setText("Salida de Materiales Por Solicitud ");

        javax.swing.GroupLayout Pan22Layout = new javax.swing.GroupLayout(Pan22);
        Pan22.setLayout(Pan22Layout);
        Pan22Layout.setHorizontalGroup(
            Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane12, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(Pan22Layout.createSequentialGroup()
                .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addGap(356, 356, 356)
                        .addComponent(btnDescontar))
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Pan22Layout.createSequentialGroup()
                                .addComponent(lblSeleccionar)
                                .addGap(18, 18, 18)
                                .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(Pan22Layout.createSequentialGroup()
                                        .addComponent(lblSolicitante, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jtxtSolicitante, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(Pan22Layout.createSequentialGroup()
                                        .addComponent(lblDepar, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jtxtDepar, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(Pan22Layout.createSequentialGroup()
                                .addComponent(lblJusticificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Pan22Layout.createSequentialGroup()
                                .addGap(205, 205, 205)
                                .addComponent(jLabel562))))
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addGap(203, 203, 203)
                        .addComponent(jSeparator356, javax.swing.GroupLayout.PREFERRED_SIZE, 371, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(257, Short.MAX_VALUE))
        );
        Pan22Layout.setVerticalGroup(
            Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan22Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel562)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator356, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8)
                .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblDepar)
                            .addComponent(jtxtDepar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                        .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblSolicitante)
                            .addComponent(jtxtSolicitante, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan22Layout.createSequentialGroup()
                        .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jComboBox7, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblSeleccionar))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGroup(Pan22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(lblJusticificacion))
                    .addGroup(Pan22Layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(56, 56, 56)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDescontar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(117, Short.MAX_VALUE))
        );

        jTabbedPane6.addTab("Con Solicitud de Materiales", Pan22);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane6)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane6)
        );

        TadP3.addTab("Entradas y Salidas", jPanel12);

        jLabel40.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel40.setText("Registro de Materiales al Inventario");

        lblCodes.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCodes.setText("Código  ");

        try {
            jtxtCodigos.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtCodigos.setToolTipText("7 digitos ");
        jtxtCodigos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigosActionPerformed(evt);
            }
        });

        jSpinnerCantidad.setToolTipText("Sólo caracteres numéricos.");
        jSpinnerCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSpinnerCantidadActionPerformed(evt);
            }
        });
        jSpinnerCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jSpinnerCantidadKeyTyped(evt);
            }
        });

        lblCanti.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCanti.setText("Cantidad");

        lblDe.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblDe.setText("Nombre");

        jtxtDescription.setEditable(false);
        try {
            jtxtDescription.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("***********************")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtDescription.setToolTipText("25 caracteres maximo");
        jtxtDescription.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDescriptionActionPerformed(evt);
            }
        });
        jtxtDescription.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtDescriptionKeyTyped(evt);
            }
        });

        jTexUbicacionRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTexUbicacionRegistroActionPerformed(evt);
            }
        });
        jTexUbicacionRegistro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTexUbicacionRegistroKeyTyped(evt);
            }
        });

        lblUbicaciones.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblUbicaciones.setText("Ubicación");

        jButton11.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton11.setText("Cargar");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Pan10Layout = new javax.swing.GroupLayout(Pan10);
        Pan10.setLayout(Pan10Layout);
        Pan10Layout.setHorizontalGroup(
            Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan10Layout.createSequentialGroup()
                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan10Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addComponent(jLabel40, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator21, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan10Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Pan10Layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(lblUbicaciones)
                                .addGap(18, 18, 18)
                                .addComponent(jTexUbicacionRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(Pan10Layout.createSequentialGroup()
                                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblCanti)
                                        .addComponent(lblDe))
                                    .addComponent(lblCodes, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(31, 31, 31)
                                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtxtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtxtCodigos, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jSpinnerCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(500, Short.MAX_VALUE))
        );
        Pan10Layout.setVerticalGroup(
            Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan10Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel40)
                .addGap(4, 4, 4)
                .addComponent(jSeparator21, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodes, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jtxtCodigos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCanti)
                    .addComponent(jSpinnerCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDe)
                    .addComponent(jtxtDescription, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Pan10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblUbicaciones)
                    .addComponent(jTexUbicacionRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(375, Short.MAX_VALUE))
        );

        TadP3.addTab("Registro", Pan10);

        jTabbedPane2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N

        Pan12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        jLabel47.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel47.setText("Creación de Materiales");

        lblCod1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCod1.setText("Código ");

        try {
            jtxtCodigo.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtCodigo.setToolTipText("7 Caracteres Alfanumericos");
        jtxtCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigoActionPerformed(evt);
            }
        });
        jtxtCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtCodigoKeyTyped(evt);
            }
        });

        try {
            jtxtDescrip.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*************************")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtDescrip.setToolTipText("25 caracteres maximo");
        jtxtDescrip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDescripActionPerformed(evt);
            }
        });
        jtxtDescrip.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtDescripKeyTyped(evt);
            }
        });

        lblDescr1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblDescr1.setText("Nombre ");

        lblCategorias1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCategorias1.setText("Categoría");

        jComboBoxCategoria.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxCategoria.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Acueducto", "Materiales", "Limpieza", "Suministros de oficina", "Herramientas" }));
        jComboBoxCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCategoriaActionPerformed(evt);
            }
        });
        jComboBoxCategoria.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBoxCategoriaKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jComboBoxCategoriaKeyTyped(evt);
            }
        });

        jTextCantMin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextCantMinActionPerformed(evt);
            }
        });
        jTextCantMin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextCantMinKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextCantMinKeyTyped(evt);
            }
        });

        jLabel31.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel31.setText("Cantidad Mínima");

        jLabel32.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel32.setText("Tipo de unidad");

        jComboBoxTipo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bolsa", "Caja", "Cubeta", "Galón", "1/4 Galón", "Laminas", "Litros", "Kit", "Kilo", "Paquete", "Pares", "Unidad" }));
        jComboBoxTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoActionPerformed(evt);
            }
        });
        jComboBoxTipo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jComboBoxTipoKeyPressed(evt);
            }
        });

        jButton14.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton14.setText("Cargar");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Pan12Layout = new javax.swing.GroupLayout(Pan12);
        Pan12.setLayout(Pan12Layout);
        Pan12Layout.setHorizontalGroup(
            Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Pan12Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jSeparator23, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(Pan12Layout.createSequentialGroup()
                        .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32)
                            .addComponent(jLabel31)
                            .addComponent(lblDescr1)
                            .addComponent(lblCod1))
                        .addGap(18, 18, 18)
                        .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxtDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextCantMin, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jComboBoxTipo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jComboBoxCategoria, javax.swing.GroupLayout.Alignment.LEADING, 0, 202, Short.MAX_VALUE))))
                    .addComponent(lblCategorias1)
                    .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 423, Short.MAX_VALUE))
        );
        Pan12Layout.setVerticalGroup(
            Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Pan12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel47)
                .addGap(4, 4, 4)
                .addComponent(jSeparator23, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCod1)
                    .addComponent(jtxtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDescr1)
                    .addComponent(jtxtDescrip, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCategorias1)
                    .addComponent(jComboBoxCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel31)
                    .addComponent(jTextCantMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Pan12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel32)
                    .addComponent(jComboBoxTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(321, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Crear", Pan12);

        jLabel46.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
        jLabel46.setText("Modificación de Materiales Existentes");

        lblCod2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCod2.setText("Código ");

        try {
            jtxtCodigoM.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtCodigoM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtCodigoMActionPerformed(evt);
            }
        });

        try {
            jtxtDescripM.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*************************")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jtxtDescripM.setToolTipText("25 caracteres maximo");
        jtxtDescripM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtDescripMActionPerformed(evt);
            }
        });
        jtxtDescripM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtxtDescripMKeyTyped(evt);
            }
        });

        lblDescr2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblDescr2.setText("Nombre ");

        lblCategorias2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblCategorias2.setText("Categoría");

        jComboBoxCategoriaM.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxCategoriaM.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Acueducto", "Materiales", "Limpieza", "Suministros de oficina", "Herramientas" }));
        jComboBoxCategoriaM.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxCategoriaMItemStateChanged(evt);
            }
        });
        jComboBoxCategoriaM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCategoriaMActionPerformed(evt);
            }
        });
        jComboBoxCategoriaM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jComboBoxCategoriaMKeyTyped(evt);
            }
        });

        jTextCantMinM.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextCantMinMKeyTyped(evt);
            }
        });

        jLabel33.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel33.setText("Cantidad Mínima");

        jLabel45.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel45.setText("Tipo de unidad");

        jComboBoxTipoM.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jComboBoxTipoM.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bolsa", "Caja", "Cubeta", "Galón", "1/4 Galón", "Laminas", "Litros", "Kit", "Kilo", "Paquete", "Pares", "Unidad" }));
        jComboBoxTipoM.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoMActionPerformed(evt);
            }
        });

        jButton19.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton19.setText("Modificar");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel33)
                                    .addComponent(jLabel45))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBoxTipoM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextCantMinM, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblDescr2)
                                    .addComponent(lblCod2))
                                .addGap(78, 78, 78)
                                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtxtDescripM, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jtxtCodigoM, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addComponent(lblCategorias2)
                                .addGap(74, 74, 74)
                                .addComponent(jComboBoxCategoriaM, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jSeparator22, javax.swing.GroupLayout.PREFERRED_SIZE, 438, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(412, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel46)
                .addGap(4, 4, 4)
                .addComponent(jSeparator22, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCod2)
                    .addComponent(jtxtCodigoM, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jtxtDescripM, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDescr2, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCategorias2)
                    .addComponent(jComboBoxCategoriaM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel33)
                    .addComponent(jTextCantMinM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel45)
                    .addComponent(jComboBoxTipoM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(305, 305, 305))
        );

        jTabbedPane2.addTab("Modificar", jPanel11);

        javax.swing.GroupLayout Pan11Layout = new javax.swing.GroupLayout(Pan11);
        Pan11.setLayout(Pan11Layout);
        Pan11Layout.setHorizontalGroup(
            Pan11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        Pan11Layout.setVerticalGroup(
            Pan11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );

        TadP3.addTab("Nuevo Material", Pan11);

        jPanel1.add(TadP3, java.awt.BorderLayout.CENTER);

        TaPa1.addTab("Inventario", jPanel1);
        jPanel1.getAccessibleContext().setAccessibleParent(TaPa1);

        jPanel23.setBackground(new java.awt.Color(153, 204, 255));
        jPanel23.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTaPa9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        lblSolicitudes.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblSolicitudes.setText("Número de solicitud");

        btnBusqueda.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        btnBusqueda.setText("Buscar");
        btnBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBusquedaActionPerformed(evt);
            }
        });

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nº  Solicitud", "Còdigo", "Cantidad", "Tipo de unidad", "Descripción", "Solicitante"
            }
        )
        {public boolean isCellEditable(int row, int column){return false;}}
    );
    jTable4.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jTable4KeyTyped(evt);
        }
    });
    jScrollPane4.setViewportView(jTable4);

    jLabel53.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel53.setText("Consultar   Solicitud de Materiales ");

    campoConsultaSolicitud.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            campoConsultaSolicitudActionPerformed(evt);
        }
    });
    campoConsultaSolicitud.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            campoConsultaSolicitudKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout Pan21Layout = new javax.swing.GroupLayout(Pan21);
    Pan21.setLayout(Pan21Layout);
    Pan21Layout.setHorizontalGroup(
        Pan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan21Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan21Layout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(jLabel53))
                .addComponent(jSeparator30, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(Pan21Layout.createSequentialGroup()
                    .addComponent(lblSolicitudes)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(campoConsultaSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(31, 31, 31)
                    .addComponent(btnBusqueda)))
            .addContainerGap(38, Short.MAX_VALUE))
    );
    Pan21Layout.setVerticalGroup(
        Pan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan21Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel53)
            .addGap(4, 4, 4)
            .addComponent(jSeparator30, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addGroup(Pan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSolicitudes)
                    .addComponent(btnBusqueda))
                .addComponent(campoConsultaSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(32, 32, 32)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(528, Short.MAX_VALUE))
    );

    jTaPa9.addTab("Consultar", Pan21);

    jPan19.setFont(new java.awt.Font("Dialog", 0, 18)); // NOI18N

    jTable3.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "Nº Solicitud", "Código", "Cantidad", "Tipo de unidad", "Descripción"
        }
    ));
    jScrollPane3.setViewportView(jTable3);

    btnCarga.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnCarga.setText("Cargar");
    btnCarga.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnCargaActionPerformed(evt);
        }
    });

    jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

    btnEnviar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnEnviar.setText("Enviar");
    btnEnviar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnEnviarActionPerformed(evt);
        }
    });
    btnEnviar.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            btnEnviarKeyTyped(evt);
        }
    });

    jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel3.setText("Justificación");

    campoJustificacionCrearSolicitud.setColumns(20);
    campoJustificacionCrearSolicitud.setRows(5);
    campoJustificacionCrearSolicitud.setToolTipText("Digite una justificación de porqué necesita el material");
    campoJustificacionCrearSolicitud.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            campoJustificacionCrearSolicitudKeyTyped(evt);
        }
    });
    jScrollPane20.setViewportView(campoJustificacionCrearSolicitud);

    jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel4.setText("Cantidad");

    jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel5.setText("Código");

    jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jLabel6.setText("Materiales");

    campoUsuario.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            campoUsuarioActionPerformed(evt);
        }
    });

    jSpinner2.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));
    jSpinner2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jSpinner2KeyTyped(evt);
        }
    });

    jLabel52.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel52.setText("Creación de  Solicitud de Materiales ");

    codCrearSolicitud.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            codCrearSolicitudKeyReleased(evt);
        }
        public void keyTyped(java.awt.event.KeyEvent evt) {
            codCrearSolicitudKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout jPan19Layout = new javax.swing.GroupLayout(jPan19);
    jPan19.setLayout(jPan19Layout);
    jPan19Layout.setHorizontalGroup(
        jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPan19Layout.createSequentialGroup()
            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPan19Layout.createSequentialGroup()
                    .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPan19Layout.createSequentialGroup()
                            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPan19Layout.createSequentialGroup()
                                    .addGap(26, 26, 26)
                                    .addComponent(jLabel52))
                                .addGroup(jPan19Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jSeparator29, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPan19Layout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPan19Layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 186, Short.MAX_VALUE)
                                    .addComponent(jLabel3))
                                .addGroup(jPan19Layout.createSequentialGroup()
                                    .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnCarga, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPan19Layout.createSequentialGroup()
                                            .addComponent(jLabel4)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPan19Layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addGap(23, 23, 23)
                                            .addComponent(codCrearSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGap(0, 0, Short.MAX_VALUE)))
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 369, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 157, Short.MAX_VALUE)))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPan19Layout.createSequentialGroup()
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 868, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 71, Short.MAX_VALUE)))
            .addContainerGap())
        .addGroup(jPan19Layout.createSequentialGroup()
            .addGap(327, 327, 327)
            .addComponent(btnEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 254, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    jPan19Layout.setVerticalGroup(
        jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPan19Layout.createSequentialGroup()
            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPan19Layout.createSequentialGroup()
                    .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPan19Layout.createSequentialGroup()
                            .addGap(25, 25, 25)
                            .addComponent(campoUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPan19Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel52)
                            .addGap(4, 4, 4)
                            .addComponent(jSeparator29, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(34, 34, 34)
                    .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPan19Layout.createSequentialGroup()
                            .addComponent(jLabel6)
                            .addGap(18, 18, 18)
                            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel5)
                                .addComponent(codCrearSolicitud, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18)
                            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel4)
                                .addComponent(jSpinner2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(jPan19Layout.createSequentialGroup()
                            .addGroup(jPan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(20, 20, 20)))
                    .addGap(28, 28, 28)
                    .addComponent(btnCarga))
                .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(31, 31, 31)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(btnEnviar)
            .addContainerGap(303, Short.MAX_VALUE))
    );

    jTaPa9.addTab("Crear", jPan19);

    Pan20.setName("Modificar"); // NOI18N

    jTable5.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {

        },
        new String [] {
            "Código", "Cantidad", "Descripción"
        }
    ));
    jScrollPane5.setViewportView(jTable5);

    lblNumero.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNumero.setText("Número de solicitud");

    btnBusca.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnBusca.setText("Buscar");
    btnBusca.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnBuscaActionPerformed(evt);
        }
    });

    lblDescripcion.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblDescripcion.setText("Cantidad nueva");

    btnEnviaCambio.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnEnviaCambio.setText("Editar");
    btnEnviaCambio.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnEnviaCambioActionPerformed(evt);
        }
    });

    jLabel34.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel34.setText("Código de material antiguo");

    jLabel35.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel35.setText("Código de material nuevo");

    jLabel51.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel51.setText("Modificación de  Solicitud de Materiales ");

    numSolicitudModificar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            numSolicitudModificarActionPerformed(evt);
        }
    });
    numSolicitudModificar.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            numSolicitudModificarKeyTyped(evt);
        }
    });

    codAntiguo.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            codAntiguoKeyReleased(evt);
        }
        public void keyTyped(java.awt.event.KeyEvent evt) {
            codAntiguoKeyTyped(evt);
        }
    });

    codNuevo.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            codNuevoActionPerformed(evt);
        }
    });
    codNuevo.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyReleased(java.awt.event.KeyEvent evt) {
            codNuevoKeyReleased(evt);
        }
        public void keyTyped(java.awt.event.KeyEvent evt) {
            codNuevoKeyTyped(evt);
        }
    });

    cantidadNueva.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            cantidadNuevaKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout Pan20Layout = new javax.swing.GroupLayout(Pan20);
    Pan20.setLayout(Pan20Layout);
    Pan20Layout.setHorizontalGroup(
        Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan20Layout.createSequentialGroup()
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblNumero)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(numSolicitudModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(btnBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(548, 548, 548))
        .addGroup(Pan20Layout.createSequentialGroup()
            .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan20Layout.createSequentialGroup()
                    .addGap(42, 42, 42)
                    .addComponent(jLabel51))
                .addGroup(Pan20Layout.createSequentialGroup()
                    .addGap(26, 26, 26)
                    .addComponent(jSeparator28, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(Pan20Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel35, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel34, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(btnEnviaCambio, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(38, 38, 38)
                    .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(codAntiguo)
                        .addComponent(codNuevo)
                        .addComponent(cantidadNueva, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE)))
                .addGroup(Pan20Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    Pan20Layout.setVerticalGroup(
        Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan20Layout.createSequentialGroup()
            .addGap(14, 14, 14)
            .addComponent(jLabel51)
            .addGap(4, 4, 4)
            .addComponent(jSeparator28, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNumero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnBusca))
                .addGroup(Pan20Layout.createSequentialGroup()
                    .addComponent(numSolicitudModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGap(18, 18, 18)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(codAntiguo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(codNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(Pan20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblDescripcion)
                .addComponent(cantidadNueva, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(18, 18, 18)
            .addComponent(btnEnviaCambio)
            .addGap(492, 492, 492))
    );

    jTaPa9.addTab("Modificar", Pan20);

    javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
    jPanel23.setLayout(jPanel23Layout);
    jPanel23Layout.setHorizontalGroup(
        jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(jTaPa9)
    );
    jPanel23Layout.setVerticalGroup(
        jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel23Layout.createSequentialGroup()
            .addComponent(jTaPa9, javax.swing.GroupLayout.PREFERRED_SIZE, 855, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );

    TaPa1.addTab("Solicitud de materiales", jPanel23);
    jPanel23.getAccessibleContext().setAccessibleParent(TaPa1);

    jPanel2.setBackground(new java.awt.Color(153, 204, 255));
    jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    TaP2.setToolTipText("");
    TaP2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    TaP2.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            TaP2MouseClicked(evt);
        }
    });

    btnCargar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnCargar.setText("Cargar");
    btnCargar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnCargarActionPerformed(evt);
        }
    });
    btnCargar.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            btnCargarKeyTyped(evt);
        }
    });

    jTable1.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {},
            {},
            {},
            {}
        },
        new String [] {

        }
    ));
    jTable1.setCellSelectionEnabled(true);
    jTable1.setComponentPopupMenu(jPopupMenu1);
    jScrollPane1.setViewportView(jTable1);

    btnCrear.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnCrear.setText("Crear");
    btnCrear.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnCrearActionPerformed(evt);
        }
    });
    btnCrear.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            btnCrearKeyTyped(evt);
        }
    });

    lblNames.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNames.setText("Empresa");

    lblCedJu.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCedJu.setText("Cedula Jurídica ");

    lblContacto.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblContacto.setText("Nombre del Contacto");

    jtxtCont.setToolTipText("Digite el nombre del contacto");
    jtxtCont.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtContKeyTyped(evt);
        }
    });

    lblProveedor.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblProveedor.setText("Código de Proveedor");

    lblCant.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCant.setText("Cantidad");

    lblTiposU.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblTiposU.setText("Tipo de Unidad");

    lblDes.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblDes.setText("Descripción");

    lblCode.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCode.setText("Código ");

    lblUnitario.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblUnitario.setText("Precio Unitario ");

    jComboBox5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jComboBox5.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bolsa", "Caja", "Cubeta", "Galón", "1/4 Galón", "Laminas", "Litros", "Kit", "Kilo", "Paquete", "Pares", "Unidad" }));

    lblNum.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNum.setText("Número de Orden");

    lblProductos.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblProductos.setText("Materiales");

    lblTotalOr.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblTotalOr.setText("Total de la Orden ¢");

    try {
        jtxtDesc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*****************")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtDesc.setToolTipText("Digite el nombre del material");

    jLabel14.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    jLabel14.setText("Apellido");

    try {
        jtxtApe.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("ULLLLLLLLLLL")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtApe.setToolTipText("Digite el apellido del contacto");
    jtxtApe.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtApeActionPerformed(evt);
        }
    });
    jtxtApe.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtApeKeyTyped(evt);
        }
    });

    try {
        jtxtCedJ.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("3-AAA-AAAAAA")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtCedJ.setToolTipText("Sólo valores numéricos");
    jtxtCedJ.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCedJKeyTyped(evt);
        }
    });

    jLabel48.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel48.setText("Creación de Órdenes de Compra");

    jtxtCode.addFocusListener(new java.awt.event.FocusAdapter() {
        public void focusLost(java.awt.event.FocusEvent evt) {
            jtxtCodeFocusLost(evt);
        }
    });
    jtxtCode.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCodeKeyTyped(evt);
        }
    });

    jtxtOrden.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtOrdenKeyTyped(evt);
        }
    });

    jTextField7.setToolTipText("7 caracteres alfanumericos");
    jTextField7.addFocusListener(new java.awt.event.FocusAdapter() {
        public void focusLost(java.awt.event.FocusEvent evt) {
            jTextField7FocusLost(evt);
        }
    });
    jTextField7.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField7ActionPerformed(evt);
        }
    });
    jTextField7.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jTextField7KeyTyped(evt);
        }
    });

    jtxtPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtPrecioKeyTyped(evt);
        }
    });

    jtxtTotales.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtTotalesKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout Pan6Layout = new javax.swing.GroupLayout(Pan6);
    Pan6.setLayout(Pan6Layout);
    Pan6Layout.setHorizontalGroup(
        Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan6Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(lblNames, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(lblCedJu)
                .addComponent(lblContacto, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(lblProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(26, 26, 26)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan6Layout.createSequentialGroup()
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jtxtCedJ, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addGap(0, 0, Short.MAX_VALUE)
                            .addComponent(jtxtCont, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jtxtApe, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(573, 573, 573))
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jTxtEmpresa, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTextField7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 87, Short.MAX_VALUE))
                    .addGap(0, 0, Short.MAX_VALUE))))
        .addGroup(Pan6Layout.createSequentialGroup()
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane1)
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(Pan6Layout.createSequentialGroup()
                                    .addGap(212, 212, 212)
                                    .addComponent(lblNum)
                                    .addGap(18, 18, 18)
                                    .addComponent(jtxtOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(Pan6Layout.createSequentialGroup()
                                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pan6Layout.createSequentialGroup()
                                            .addComponent(lblDes)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jtxtDesc, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblProductos, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pan6Layout.createSequentialGroup()
                                                    .addComponent(lblCode)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                    .addComponent(jtxtCode, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pan6Layout.createSequentialGroup()
                                                    .addComponent(lblTiposU)
                                                    .addGap(18, 18, 18)
                                                    .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                    .addGap(61, 61, 61)
                                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(Pan6Layout.createSequentialGroup()
                                            .addComponent(lblCant)
                                            .addGap(54, 54, 54)
                                            .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(Pan6Layout.createSequentialGroup()
                                            .addComponent(lblUnitario)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jtxtPrecio))
                                        .addComponent(btnCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addGap(42, 42, 42)
                            .addComponent(jLabel48, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jSeparator24, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jSeparator25, javax.swing.GroupLayout.PREFERRED_SIZE, 919, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(Pan6Layout.createSequentialGroup()
                            .addGap(29, 29, 29)
                            .addComponent(btnCrear, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(124, 124, 124)
                            .addComponent(lblTotalOr, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jtxtTotales, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    Pan6Layout.setVerticalGroup(
        Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan6Layout.createSequentialGroup()
            .addGap(12, 12, 12)
            .addComponent(jLabel48)
            .addGap(4, 4, 4)
            .addComponent(jSeparator24, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGap(30, 30, 30)
                    .addComponent(lblProveedor)
                    .addGap(11, 11, 11))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan6Layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)))
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addComponent(lblCedJu)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(lblContacto))
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(lblNames)
                        .addComponent(jTxtEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jtxtCedJ, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(9, 9, 9)
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jtxtCont, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14)
                        .addComponent(jtxtApe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGap(14, 14, 14)
            .addComponent(jSeparator25, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblNum)
                            .addComponent(jtxtOrden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(lblProductos))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCode)
                        .addComponent(jtxtCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGap(47, 47, 47)
                    .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCant)
                        .addComponent(jSpinner3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGap(18, 18, 18)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblTiposU)
                .addComponent(jComboBox5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(lblUnitario)
                .addComponent(jtxtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(18, 18, 18)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblDes)
                .addComponent(jtxtDesc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnCargar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(32, 32, 32)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(14, 14, 14)
            .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTotalOr)
                    .addComponent(jtxtTotales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(Pan6Layout.createSequentialGroup()
                    .addGap(2, 2, 2)
                    .addComponent(btnCrear)))
            .addContainerGap(74, Short.MAX_VALUE))
    );

    javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
    jPanel27.setLayout(jPanel27Layout);
    jPanel27Layout.setHorizontalGroup(
        jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel27Layout.createSequentialGroup()
            .addComponent(Pan6, javax.swing.GroupLayout.PREFERRED_SIZE, 935, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );
    jPanel27Layout.setVerticalGroup(
        jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(Pan6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
    );

    TaP2.addTab("Crear", jPanel27);

    jTable2.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {},
            {},
            {},
            {}
        },
        new String [] {

        }
    ));
    jTable2.setComponentPopupMenu(jPopupMenu1);
    jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            jTable2MouseClicked(evt);
        }
    });
    jScrollPane2.setViewportView(jTable2);

    lblNumCompra.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
    lblNumCompra.setText("Número de Orden de Compra");

    btnGuardar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnGuardar.setText("Guardar");
    btnGuardar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnGuardarActionPerformed(evt);
        }
    });
    btnGuardar.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            btnGuardarKeyTyped(evt);
        }
    });

    btnConsultar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnConsultar.setText("Consultar");
    btnConsultar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnConsultarActionPerformed(evt);
        }
    });

    lblTotalOrde.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
    lblTotalOrde.setText("Total de la Orden ¢");

    lblEstate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblEstate.setText("Estado");

    jComboBox6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jComboBox6.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Pendiente", "Incompleta", "Entregada" }));

    lblPro.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblPro.setText("Proveedor");

    lblNom.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNom.setText("Nombre");

    lblApe.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    lblApe.setText("Apellido");

    lblCedJuri.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCedJuri.setText("Cedula Jurídica ");

    try {
        jtxtCedula.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("3-AAA-AAAAAA")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }

    lblCon.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCon.setText("Código");

    jLabel49.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel49.setText("Modificar  Órdenes de Compra");

    jtxtTotal.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtTotalKeyTyped(evt);
        }
    });

    jtxtNumeroOrden.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtNumeroOrdenKeyTyped(evt);
        }
    });

    jtxtCodg.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCodgKeyTyped(evt);
        }
    });

    lblProductos1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblProductos1.setText("Materiales");

    lblCode1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCode1.setText("Código ");

    lblTiposU1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblTiposU1.setText("Tipo de Unidad");

    lblDes1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblDes1.setText("Descripción");

    lblCant1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCant1.setText("Cantidad");

    lblUnitario1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblUnitario1.setText("Precio Unitario ");

    jtxtCode1.addFocusListener(new java.awt.event.FocusAdapter() {
        public void focusLost(java.awt.event.FocusEvent evt) {
            jtxtCode1FocusLost(evt);
        }
    });
    jtxtCode1.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCode1KeyTyped(evt);
        }
    });

    jComboBox8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jComboBox8.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bolsa", "Caja", "Cubeta", "Galón", "1/4 Galón", "Laminas", "Litros", "Kit", "Kilo", "Paquete", "Pares", "Unidad" }));

    jtxtPrecio1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtPrecio1ActionPerformed(evt);
        }
    });
    jtxtPrecio1.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtPrecio1KeyTyped(evt);
        }
    });

    jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);

    jButton1.setText("Editar producto");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton1ActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout Pan7Layout = new javax.swing.GroupLayout(Pan7);
    Pan7.setLayout(Pan7Layout);
    Pan7Layout.setHorizontalGroup(
        Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan7Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addComponent(jSeparator26, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addComponent(lblEstate)
                    .addGap(18, 18, 18)
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan7Layout.createSequentialGroup()
                            .addComponent(lblProductos1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(29, 29, 29)
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Pan7Layout.createSequentialGroup()
                                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblNom)
                                        .addComponent(lblCon))
                                    .addGap(26, 26, 26)
                                    .addComponent(lblPro, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(Pan7Layout.createSequentialGroup()
                                    .addComponent(lblCedJuri)
                                    .addGap(23, 23, 23)
                                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(Pan7Layout.createSequentialGroup()
                                            .addComponent(jtxtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(lblApe)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jtxtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jtxtCodg)
                                        .addComponent(jtxtCedula))))
                            .addGap(77, 77, 77))
                        .addGroup(Pan7Layout.createSequentialGroup()
                            .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan7Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(lblNumCompra)
                    .addGap(18, 18, 18)
                    .addComponent(jtxtNumeroOrden, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(btnConsultar)
                    .addGap(486, 486, 486))
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addGap(32, 32, 32)
                    .addComponent(jLabel49, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(numAux, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))))
        .addGroup(Pan7Layout.createSequentialGroup()
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addGap(39, 39, 39)
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan7Layout.createSequentialGroup()
                            .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(152, 152, 152)
                            .addComponent(lblTotalOrde)
                            .addGap(18, 18, 18)
                            .addComponent(jtxtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 734, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan7Layout.createSequentialGroup()
                                .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pan7Layout.createSequentialGroup()
                                        .addComponent(lblUnitario1)
                                        .addGap(18, 18, 18)
                                        .addComponent(jtxtPrecio1))
                                    .addGroup(Pan7Layout.createSequentialGroup()
                                        .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Pan7Layout.createSequentialGroup()
                                                    .addComponent(lblDes1)
                                                    .addGap(28, 28, 28))
                                                .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(lblCode1, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(lblTiposU1, javax.swing.GroupLayout.Alignment.LEADING)))
                                            .addComponent(lblCant1))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jtxtCode1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jSpinner4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jtxtDesc1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(439, 439, 439))
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addGap(55, 55, 55)
                    .addComponent(jSeparator14, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    Pan7Layout.setVerticalGroup(
        Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan7Layout.createSequentialGroup()
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel49))
                .addComponent(numAux, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(4, 4, 4)
            .addComponent(jSeparator26, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblNumCompra)
                .addComponent(jtxtNumeroOrden, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnConsultar, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblEstate)
                .addComponent(jComboBox6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(17, 17, 17)
            .addComponent(jSeparator14, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan7Layout.createSequentialGroup()
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblPro)
                        .addComponent(lblProductos1))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan7Layout.createSequentialGroup()
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblCon)
                                .addComponent(jtxtCodg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblNom)
                                .addComponent(lblApe)
                                .addComponent(jtxtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jtxtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(8, 8, 8)
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblCedJuri)
                                .addComponent(jtxtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(Pan7Layout.createSequentialGroup()
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblCode1)
                                .addComponent(jtxtCode1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblTiposU1)
                                .addComponent(jComboBox8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblDes1)
                                .addComponent(jtxtDesc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCant1)
                        .addComponent(jSpinner4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblUnitario1)
                        .addComponent(jtxtPrecio1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addComponent(jSeparator9, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(3, 3, 3)
            .addComponent(jButton1)
            .addGap(18, 18, 18)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(22, 22, 22)
            .addGroup(Pan7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblTotalOrde)
                .addComponent(jtxtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(86, Short.MAX_VALUE))
    );

    TaP2.addTab("Modificar", Pan7);

    jTableOrden.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {},
            {},
            {},
            {}
        },
        new String [] {

        }
    ));
    jScrollPane6.setViewportView(jTableOrden);

    lblOrdenCompra.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblOrdenCompra.setText("Número de orden de compra");

    btnBuscar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnBuscar.setText("Buscar");
    btnBuscar.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnBuscarActionPerformed(evt);
        }
    });

    lblTotalOrdenes.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
    lblTotalOrdenes.setText("Total de la orden ¢");

    lblContact.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblContact.setText("Código");

    lblCed.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCed.setText("Cédula Jurídica ");

    try {
        jtxtCed.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("3-AAA-AAAAAA")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }

    try {
        jtxtName.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("ULLLLLLLLLLLLL")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtName.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtNameActionPerformed(evt);
        }
    });
    jtxtName.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtNameKeyTyped(evt);
        }
    });

    lblNombres.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNombres.setText("Nombre");

    try {
        jtxtLast.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("ULLLLLLLLLLL")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtLast.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtLastActionPerformed(evt);
        }
    });
    jtxtLast.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtLastKeyTyped(evt);
        }
    });

    lblApellidos.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    lblApellidos.setText("Apellido");

    lblProveedores.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblProveedores.setText("Proveedor");

    jLabel50.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel50.setText("Consulta de  Órdenes de Compra");

    jSeparator7.setOrientation(javax.swing.SwingConstants.VERTICAL);

    jtxtCodgC.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCodgCKeyTyped(evt);
        }
    });

    jtxtOrdenCOmpre.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtOrdenCOmpreKeyTyped(evt);
        }
    });

    jTextTot.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextTotActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout Pan8Layout = new javax.swing.GroupLayout(Pan8);
    Pan8.setLayout(Pan8Layout);
    Pan8Layout.setHorizontalGroup(
        Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan8Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan8Layout.createSequentialGroup()
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addComponent(lblOrdenCompra)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jtxtOrdenCOmpre, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(32, 32, 32)
                    .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblCed)
                                    .addComponent(lblContact, javax.swing.GroupLayout.Alignment.LEADING))
                                .addComponent(lblNombres))
                            .addGap(59, 59, 59)
                            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(Pan8Layout.createSequentialGroup()
                                    .addComponent(jtxtName, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(lblApellidos)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jtxtLast, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jtxtCodgC, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jtxtCed, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE))))
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addGap(123, 123, 123)
                            .addComponent(lblProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(Pan8Layout.createSequentialGroup()
                    .addGap(217, 217, 217)
                    .addComponent(lblTotalOrdenes, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jTextTot, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE))))
        .addGroup(Pan8Layout.createSequentialGroup()
            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addGap(32, 32, 32)
                            .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jSeparator27, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 933, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(0, 0, Short.MAX_VALUE))
    );
    Pan8Layout.setVerticalGroup(
        Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Pan8Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel50)
            .addGap(4, 4, 4)
            .addComponent(jSeparator27, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan8Layout.createSequentialGroup()
                    .addComponent(lblProveedores)
                    .addGap(13, 13, 13)
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblNombres)
                        .addComponent(jtxtName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblApellidos)
                        .addComponent(jtxtLast, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblCed)
                        .addComponent(jtxtCed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addGap(9, 9, 9)
                            .addComponent(lblContact))
                        .addGroup(Pan8Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(jtxtCodgC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(Pan8Layout.createSequentialGroup()
                    .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblOrdenCompra)
                        .addComponent(jtxtOrdenCOmpre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(btnBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(45, 45, 45)
            .addGroup(Pan8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(lblTotalOrdenes)
                .addComponent(jTextTot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addContainerGap(188, Short.MAX_VALUE))
    );

    TaP2.addTab("Consultar", Pan8);

    javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
    jPanel2.setLayout(jPanel2Layout);
    jPanel2Layout.setHorizontalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
            .addComponent(TaP2, javax.swing.GroupLayout.PREFERRED_SIZE, 936, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );
    jPanel2Layout.setVerticalGroup(
        jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(TaP2)
    );

    TaP2.getAccessibleContext().setAccessibleName("Crear");

    TaPa1.addTab("Órdenes de Compra", jPanel2);
    jPanel2.getAccessibleContext().setAccessibleParent(TaPa1);

    jPanel6.setBackground(new java.awt.Color(153, 204, 255));
    jPanel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    TadP6.setBackground(new java.awt.Color(0, 51, 102));
    TadP6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

    Pan16.setLayout(null);

    lblUsers1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblUsers1.setText("Tipo de Usuario");
    Pan16.add(lblUsers1);
    lblUsers1.setBounds(20, 280, 125, 20);

    jCBoxTipoUsua.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jCBoxTipoUsua.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Administrador", "Proveduria", "Bodega ", "Departamental" }));
    Pan16.add(jCBoxTipoUsua);
    jCBoxTipoUsua.setBounds(240, 280, 200, 28);

    lblUser3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblUser3.setText("Nombre");
    Pan16.add(lblUser3);
    lblUser3.setBounds(20, 80, 63, 20);

    try {
        jtxtUser3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("**********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtUser3.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtUser3KeyTyped(evt);
        }
    });
    Pan16.add(jtxtUser3);
    jtxtUser3.setBounds(240, 80, 200, 20);

    lblContraseña2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblContraseña2.setText("Contraseña");
    Pan16.add(lblContraseña2);
    lblContraseña2.setBounds(20, 190, 89, 20);

    jtxtContraseña2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtContraseña2KeyTyped(evt);
        }
    });
    Pan16.add(jtxtContraseña2);
    jtxtContraseña2.setBounds(240, 190, 200, 20);

    lblRepetir2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblRepetir2.setText("Repetir Contraseña");
    Pan16.add(lblRepetir2);
    lblRepetir2.setBounds(20, 230, 151, 20);

    jtxtRepetir2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtRepetir2KeyTyped(evt);
        }
    });
    Pan16.add(jtxtRepetir2);
    jtxtRepetir2.setBounds(240, 230, 200, 20);

    lblLastName2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblLastName2.setText("Apellido");
    Pan16.add(lblLastName2);
    lblLastName2.setBounds(20, 110, 66, 20);

    try {
        jtxtApel2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("***********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtApel2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtApel2ActionPerformed(evt);
        }
    });
    jtxtApel2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtApel2KeyTyped(evt);
        }
    });
    Pan16.add(jtxtApel2);
    jtxtApel2.setBounds(240, 110, 200, 20);

    lblPuesto2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblPuesto2.setText("Departamento");
    Pan16.add(lblPuesto2);
    lblPuesto2.setBounds(20, 320, 120, 20);

    try {
        jtxtDepa.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("***********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtDepa.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtDepaActionPerformed(evt);
        }
    });
    jtxtDepa.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtDepaKeyTyped(evt);
        }
    });
    Pan16.add(jtxtDepa);
    jtxtDepa.setBounds(240, 320, 200, 20);

    lblDescri2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblDescri2.setText("Descripción ");
    Pan16.add(lblDescri2);
    lblDescri2.setBounds(20, 370, 96, 20);

    try {
        jtxtDes2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("***********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtDes2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtDes2ActionPerformed(evt);
        }
    });
    jtxtDes2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtDes2KeyTyped(evt);
        }
    });
    Pan16.add(jtxtDes2);
    jtxtDes2.setBounds(240, 370, 200, 20);

    btnCrearUsuario1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    btnCrearUsuario1.setText("Crear Usuario");
    btnCrearUsuario1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnCrearUsuario1ActionPerformed(evt);
        }
    });
    btnCrearUsuario1.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            btnCrearUsuario1KeyTyped(evt);
        }
    });
    Pan16.add(btnCrearUsuario1);
    btnCrearUsuario1.setBounds(20, 420, 238, 40);
    Pan16.add(jLabel36);
    jLabel36.setBounds(30, 33, 0, 0);

    lblUser4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblUser4.setText("Nombre de Usuario");
    Pan16.add(lblUser4);
    lblUser4.setBounds(20, 150, 160, 20);

    try {
        jtxtNick.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("**********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtNick.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtNickKeyTyped(evt);
        }
    });
    Pan16.add(jtxtNick);
    jtxtNick.setBounds(240, 150, 200, 20);

    jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adduser_añadir_3553-2.png"))); // NOI18N
    Pan16.add(jLabel37);
    jLabel37.setBounds(420, 20, 520, 520);

    jLabel38.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel38.setText("Ingrese los datos del nuevo Usuario");
    Pan16.add(jLabel38);
    jLabel38.setBounds(20, 10, 360, 28);
    Pan16.add(jSeparator17);
    jSeparator17.setBounds(20, 42, 420, 10);

    TadP6.addTab("Crear usuario", Pan16);

    lblFiltro1.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    lblFiltro1.setText("Filtro de Búsqueda ");

    jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/removetheuser_elimina_3541-2.png"))); // NOI18N

    try {
        jtxIDUSU.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxIDUSU.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxIDUSUActionPerformed(evt);
        }
    });

    lblId3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblId3.setText("Id de Usuario");

    lblUserName1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblUserName1.setText("Nombre de Usuario");

    try {
        jtxtId3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtId3.setEnabled(false);
    jtxtId3.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtId3KeyTyped(evt);
        }
    });

    jLabel43.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jLabel43.setText("Descripción  ");

    jTextArea4.setColumns(20);
    jTextArea4.setRows(5);
    jScrollPane7.setViewportView(jTextArea4);

    jButton7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jButton7.setText("Deshabilitar Usuario");
    jButton7.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton7ActionPerformed(evt);
        }
    });

    jButton12.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jButton12.setText("Rehabilitar Usuario");
    jButton12.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton12ActionPerformed(evt);
        }
    });

    javax.swing.GroupLayout Pan19Layout = new javax.swing.GroupLayout(Pan19);
    Pan19.setLayout(Pan19Layout);
    Pan19Layout.setHorizontalGroup(
        Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan19Layout.createSequentialGroup()
            .addGap(1290, 1290, 1290)
            .addComponent(jSeparator19, javax.swing.GroupLayout.DEFAULT_SIZE, 1, Short.MAX_VALUE))
        .addGroup(Pan19Layout.createSequentialGroup()
            .addGap(23, 23, 23)
            .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(lblFiltro1)
                .addComponent(jSeparator20, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel43)
                    .addComponent(jScrollPane7)
                    .addGroup(Pan19Layout.createSequentialGroup()
                        .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblUserName1)
                            .addComponent(lblId3))
                        .addGap(18, 18, 18)
                        .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jtxtId3, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jtxIDUSU, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGap(69, 69, 69)
            .addComponent(jLabel42)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    Pan19Layout.setVerticalGroup(
        Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan19Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan19Layout.createSequentialGroup()
                    .addComponent(lblFiltro1)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addComponent(jSeparator20, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblId3)
                        .addComponent(jtxIDUSU, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(Pan19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblUserName1)
                        .addComponent(jtxtId3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addComponent(jLabel43)
                    .addGap(26, 26, 26)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(18, 18, 18)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jLabel42))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
            .addComponent(jSeparator19, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(59, 59, 59))
    );

    TadP6.addTab("Deshabilitar Usuario", Pan19);

    jPanel10.setLayout(null);

    jLabel39.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel39.setText("Filtro de Búsqueda");
    jPanel10.add(jLabel39);
    jLabel39.setBounds(20, 10, 191, 28);

    jButton5.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
    jButton5.setText("Guardar Cambios");
    jPanel10.add(jButton5);
    jButton5.setBounds(1110, 823, 352, 66);
    jPanel10.add(jSeparator18);
    jSeparator18.setBounds(10, 50, 520, 10);

    jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/editar-icono-de-usuario-61596.png"))); // NOI18N
    jPanel10.add(jLabel41);
    jLabel41.setBounds(470, 30, 480, 520);
    jPanel10.add(jSeparator10);
    jSeparator10.setBounds(10, 120, 520, 2);

    lblId2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblId2.setText("Id de Usuario");
    jPanel10.add(lblId2);
    lblId2.setBounds(10, 60, 106, 22);

    try {
        jtxtId2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("*********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtId2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtId2ActionPerformed(evt);
        }
    });
    jPanel10.add(jtxtId2);
    jtxtId2.setBounds(240, 60, 167, 20);

    jTextNombreMod.setEnabled(false);
    jTextNombreMod.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jTextNombreModKeyTyped(evt);
        }
    });
    jPanel10.add(jTextNombreMod);
    jTextNombreMod.setBounds(240, 90, 170, 20);

    jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jLabel7.setText("Nombre ");
    jPanel10.add(jLabel7);
    jLabel7.setBounds(10, 90, 70, 22);

    lblUser5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblUser5.setText("Nombre de usuario");
    jPanel10.add(lblUser5);
    lblUser5.setBounds(10, 130, 160, 22);

    try {
        jtxtUser4.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("**********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jPanel10.add(jtxtUser4);
    jtxtUser4.setBounds(240, 140, 294, 20);
    jPanel10.add(jtxtContraseña3);
    jtxtContraseña3.setBounds(240, 180, 294, 20);

    lblContraseña3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblContraseña3.setText("Contraseña");
    jPanel10.add(lblContraseña3);
    lblContraseña3.setBounds(10, 170, 89, 22);

    lblPuesto3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblPuesto3.setText("Departamento");
    jPanel10.add(lblPuesto3);
    lblPuesto3.setBounds(10, 220, 130, 22);

    try {
        jtstdepa2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("***********")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtstdepa2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtstdepa2ActionPerformed(evt);
        }
    });
    jtstdepa2.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtstdepa2KeyTyped(evt);
        }
    });
    jPanel10.add(jtstdepa2);
    jtstdepa2.setBounds(240, 220, 167, 20);

    jComboBox13.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jComboBox13.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Administrador", "SuperUsuario\t", "Proveduria", "Bodega ", "Mantenimiento ", "Departamental" }));
    jPanel10.add(jComboBox13);
    jComboBox13.setBounds(240, 270, 160, 20);

    lblTipos2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    lblTipos2.setText("Tipo de Usuario");
    jPanel10.add(lblTipos2);
    lblTipos2.setBounds(10, 270, 125, 22);

    jButton6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jButton6.setText("Guardar Cambios");
    jButton6.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton6ActionPerformed(evt);
        }
    });
    jPanel10.add(jButton6);
    jButton6.setBounds(10, 390, 400, 60);

    TadP6.addTab("Modificar Usuario", jPanel10);

    javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
    jPanel6.setLayout(jPanel6Layout);
    jPanel6Layout.setHorizontalGroup(
        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(TadP6)
    );
    jPanel6Layout.setVerticalGroup(
        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(TadP6)
    );

    TaPa1.addTab("Administración de Usuarios", jPanel6);
    jPanel6.getAccessibleContext().setAccessibleParent(TaPa1);

    jPanel5.setBackground(new java.awt.Color(153, 204, 255));
    jPanel5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

    TadP5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

    TadP7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

    btnMostrar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnMostrar.setText("Mostrar");

    jTable16.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null, null},
            {null, null, null, null, null},
            {null, null, null, null, null},
            {null, null, null, null, null}
        },
        new String [] {
            "Numero de OC", "Hora de ingreso", "Persona quien ingresa", "Proveedor", "Estado de la Orden"
        }
    ));
    jScrollPane17.setViewportView(jTable16);

    javax.swing.GroupLayout Pan14Layout = new javax.swing.GroupLayout(Pan14);
    Pan14.setLayout(Pan14Layout);
    Pan14Layout.setHorizontalGroup(
        Pan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan14Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(Pan14Layout.createSequentialGroup()
                    .addComponent(btnMostrar)
                    .addGap(0, 0, Short.MAX_VALUE))
                .addComponent(jScrollPane17, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE))
            .addContainerGap())
    );
    Pan14Layout.setVerticalGroup(
        Pan14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan14Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(btnMostrar)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(377, Short.MAX_VALUE))
    );

    TadP7.addTab("Órdenes de compra", Pan14);

    btnMuestra.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnMuestra.setText("Mostrar");

    jTable17.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Número de Solicitud", "Hora de ingreso", "Quien ingresa", "Quien autoriza"
        }
    ));
    jScrollPane18.setViewportView(jTable17);

    javax.swing.GroupLayout Pan24Layout = new javax.swing.GroupLayout(Pan24);
    Pan24.setLayout(Pan24Layout);
    Pan24Layout.setHorizontalGroup(
        Pan24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan24Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(btnMuestra)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addComponent(jScrollPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 1029, Short.MAX_VALUE)
    );
    Pan24Layout.setVerticalGroup(
        Pan24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan24Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(btnMuestra)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(376, Short.MAX_VALUE))
    );

    TadP7.addTab("Solicitudes de materiales", Pan24);

    btnMuestras.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    btnMuestras.setText("Mostrar Todo");

    jTable18.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Hora de ingreso", "Hora de salida", "Nombre del Usuario", "Cargo"
        }
    ));
    jScrollPane19.setViewportView(jTable18);

    jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
    jLabel18.setText("Búsqueda específica");

    jLabel19.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel19.setText("Identificación:");

    jTextField8.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTextField8ActionPerformed(evt);
        }
    });

    jButton10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jButton10.setText("Buscar Usuario");

    javax.swing.GroupLayout Pan25Layout = new javax.swing.GroupLayout(Pan25);
    Pan25.setLayout(Pan25Layout);
    Pan25Layout.setHorizontalGroup(
        Pan25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan25Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(Pan25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 1009, Short.MAX_VALUE)
                .addGroup(Pan25Layout.createSequentialGroup()
                    .addGroup(Pan25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(btnMuestras)
                        .addComponent(jLabel18)
                        .addGroup(Pan25Layout.createSequentialGroup()
                            .addComponent(jLabel19)
                            .addGap(38, 38, 38)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jButton10)))
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addContainerGap())
    );
    Pan25Layout.setVerticalGroup(
        Pan25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan25Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel18)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(Pan25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel19)
                .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jButton10))
            .addGap(48, 48, 48)
            .addComponent(btnMuestras)
            .addGap(37, 37, 37)
            .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(249, Short.MAX_VALUE))
    );

    TadP7.addTab("Usuarios Logueados", Pan25);

    javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
    jPanel16.setLayout(jPanel16Layout);
    jPanel16Layout.setHorizontalGroup(
        jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel16Layout.createSequentialGroup()
            .addGap(0, 0, 0)
            .addComponent(TadP7)
            .addGap(29, 29, 29))
    );
    jPanel16Layout.setVerticalGroup(
        jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel16Layout.createSequentialGroup()
            .addComponent(TadP7, javax.swing.GroupLayout.PREFERRED_SIZE, 651, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 3782, Short.MAX_VALUE))
    );

    TadP5.addTab("Registro  de Activos", jPanel16);

    jTable15.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null},
            {null, null, null, null}
        },
        new String [] {
            "Usuarios conectados", "Ordenes de compra ingresadas", "Solicitudes de materiales ingresadas", "Modificaciones realizadas"
        }
    ));
    jScrollPane16.setViewportView(jTable15);

    javax.swing.GroupLayout Pan17Layout = new javax.swing.GroupLayout(Pan17);
    Pan17.setLayout(Pan17Layout);
    Pan17Layout.setHorizontalGroup(
        Pan17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan17Layout.createSequentialGroup()
            .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 1063, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );
    Pan17Layout.setVerticalGroup(
        Pan17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(Pan17Layout.createSequentialGroup()
            .addGap(66, 66, 66)
            .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(4156, Short.MAX_VALUE))
    );

    TadP5.addTab("Registro del sistema", Pan17);

    javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
    jPanel5.setLayout(jPanel5Layout);
    jPanel5Layout.setHorizontalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addComponent(TadP5, javax.swing.GroupLayout.Alignment.TRAILING)
    );
    jPanel5Layout.setVerticalGroup(
        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel5Layout.createSequentialGroup()
            .addComponent(TadP5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 0, Short.MAX_VALUE))
    );

    TaPa1.addTab("Bitácora", jPanel5);
    jPanel5.getAccessibleContext().setAccessibleParent(TaPa1);

    jTabbedPane3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

    jLabel10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel10.setText("Codigo de Proveedor");

    jLabel11.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel11.setText("Nombre de Proveedor");

    jTable21.setModel(new javax.swing.table.DefaultTableModel(
        new Object [][] {
            {}
        },
        new String [] {

        }
    ));
    jScrollPane26.setViewportView(jTable21);

    jBuscaNomProve.setToolTipText("Digite el nombre del proveedor para realizar la búsqueda");

    jButton4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jButton4.setText("Buscar ");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton4ActionPerformed(evt);
        }
    });

    jLabel12.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel12.setText("Dirección");

    jtxtDirecProveBuscar.setColumns(20);
    jtxtDirecProveBuscar.setRows(5);
    jScrollPane27.setViewportView(jtxtDirecProveBuscar);

    jLabel55.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel55.setText("Consulta de Proveedores");

    jBuscaCodProve.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jBuscaCodProveKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
    jPanel8.setLayout(jPanel8Layout);
    jPanel8Layout.setHorizontalGroup(
        jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel8Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel10)
                        .addComponent(jLabel11))
                    .addGap(43, 43, 43)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jBuscaNomProve, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jBuscaCodProve, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jScrollPane26, javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane27, javax.swing.GroupLayout.DEFAULT_SIZE, 806, Short.MAX_VALUE)))
                    .addGap(24, 24, 24))
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jSeparator33, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel55, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE))))
    );
    jPanel8Layout.setVerticalGroup(
        jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel8Layout.createSequentialGroup()
            .addGap(5, 5, 5)
            .addComponent(jLabel55)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(jSeparator33, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel10)
                .addComponent(jBuscaCodProve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel11)
                .addComponent(jBuscaNomProve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(18, 18, 18)
            .addComponent(jScrollPane26, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(26, 26, 26)
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane27, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel12))
            .addContainerGap(356, Short.MAX_VALUE))
    );

    jTabbedPane3.addTab("Consulta", jPanel8);

    jPanel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

    lblNames01.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblNames01.setText("Empresa");

    lblCedJu01.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblCedJu01.setText("Cédula Jurídica ");

    lblContacto01.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblContacto01.setText("Nombre del Contacto");

    lblTel01.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblTel01.setText("Teléfono ");

    lblDirection01.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    lblDirection01.setText("Dirección");

    try {
        jtxtTele01.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-##-##")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtTele01.setToolTipText("Digite el teléfono del proveedor");
    jtxtTele01.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtTele01KeyTyped(evt);
        }
    });

    jTxtEmpresa01.setToolTipText("Digite el nombre de la empresa del proveedor");
    jTxtEmpresa01.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jTxtEmpresa01ActionPerformed(evt);
        }
    });

    try {
        jtxtCedJ01.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("3-AAA-AAAAAA")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jtxtCedJ01.setToolTipText("Sólo valores numéricos");
    jtxtCedJ01.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jtxtCedJ01ActionPerformed(evt);
        }
    });
    jtxtCedJ01.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtCedJ01KeyTyped(evt);
        }
    });

    jLabela15.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabela15.setText("Apellido");

    jTextAreaDir.setColumns(20);
    jTextAreaDir.setRows(5);
    jTextAreaDir.setToolTipText("Digite la dirección del proveedor");
    jScrollPane23.setViewportView(jTextAreaDir);

    jLabela10.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabela10.setText("Código de proveedor");

    jButton3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jButton3.setText("Crear Proveedor");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton3ActionPerformed(evt);
        }
    });
    jButton3.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jButton3KeyTyped(evt);
        }
    });

    jtxtNombre01.setToolTipText("Digite el nombre del contacto");
    jtxtNombre01.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtNombre01KeyTyped(evt);
        }
    });

    jtxtApe01.setToolTipText("Digite el apellido del contacto");
    jtxtApe01.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jtxtApe01KeyTyped(evt);
        }
    });

    jLabel28.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel28.setText("Categoría");

    jTextCategoria.setToolTipText("Por ejemplo: Herramientas,acueductos,limpieza, etc");
    jTextCategoria.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jTextCategoriaKeyTyped(evt);
        }
    });

    jLabel44.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel44.setText("Creación de Proveedores");

    NProveedor01.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            NProveedor01KeyTyped(evt);
        }
    });

    javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
    jPanel7.setLayout(jPanel7Layout);
    jPanel7Layout.setHorizontalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel7Layout.createSequentialGroup()
            .addContainerGap()
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jSeparator31, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(jPanel7Layout.createSequentialGroup()
                                    .addComponent(lblNames01)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTxtEmpresa01, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel7Layout.createSequentialGroup()
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lblContacto01)
                                        .addComponent(lblCedJu01)
                                        .addComponent(jLabel28)
                                        .addComponent(lblTel01))
                                    .addGap(59, 59, 59)
                                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jTextCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel7Layout.createSequentialGroup()
                                                .addComponent(jtxtNombre01, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabela15)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jtxtApe01))
                                            .addComponent(jtxtCedJ01, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                                            .addComponent(jtxtTele01, javax.swing.GroupLayout.Alignment.LEADING)))))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblDirection01)
                                .addComponent(jLabela10)))
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(NProveedor01, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addContainerGap(71, Short.MAX_VALUE))
    );
    jPanel7Layout.setVerticalGroup(
        jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel7Layout.createSequentialGroup()
            .addComponent(jLabel44)
            .addGap(4, 4, 4)
            .addComponent(jSeparator31, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                            .addGap(101, 101, 101)
                            .addComponent(lblContacto01))
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblNames01)
                                .addComponent(jTxtEmpresa01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel28)
                                .addComponent(jTextCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jtxtCedJ01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblCedJu01, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jtxtNombre01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabela15)
                                .addComponent(jtxtApe01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jtxtTele01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblTel01))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabela10)
                        .addComponent(NProveedor01, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(lblDirection01))
                        .addGroup(jPanel7Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)))))
            .addContainerGap(425, Short.MAX_VALUE))
    );

    jTabbedPane3.addTab("Crear", jPanel7);

    jLabel13.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel13.setText("Código de Proveedor");

    jLabel15.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel15.setText("Nombre de Proveedor");

    jBotonBuscaMod.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jBotonBuscaMod.setText("Buscar");
    jBotonBuscaMod.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jBotonBuscaModActionPerformed(evt);
        }
    });

    jModifNomProve.setToolTipText("Digite el nombre del proveedor");
    jModifNomProve.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jModifNomProveActionPerformed(evt);
        }
    });

    jLabel17.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel17.setText("Dirección");

    jDirecProveModif.setColumns(20);
    jDirecProveModif.setRows(5);
    jDirecProveModif.setToolTipText("Digite la dirección del proveedor");
    jScrollPane28.setViewportView(jDirecProveModif);

    jButton8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jButton8.setText("Modificar");
    jButton8.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jButton8ActionPerformed(evt);
        }
    });

    jLabel22.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel22.setText("Nuevo Código de Proveedor");

    jLabel23.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel23.setText("Empresa");

    jLabel24.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel24.setText("Cédula Jurídica");

    jLabel25.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel25.setText("Nuevo Nombre del Contacto");

    jModifNom.setToolTipText("Digite el nombre del contacto");
    jModifNom.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            jModifNomActionPerformed(evt);
        }
    });

    jLabel26.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    jLabel26.setText("Apellido");

    jModifApel.setToolTipText("Digite el apellido del contacto");

    jLabel27.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel27.setText("Teléfono");

    jModifEmpresa.setToolTipText("Digite el nombre del proveedor");

    jLabel29.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
    jLabel29.setText("Categoría");

    jModifCategoria.setToolTipText("Por ejemplo: Herramientas,acueductos,limpieza, etc");

    jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);

    try {
        jModifTel.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("####-##-##")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jModifTel.setToolTipText("Digite numero de telefono ");

    try {
        jModifCedJur.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("3-AAA-AAAAAA")));
    } catch (java.text.ParseException ex) {
        ex.printStackTrace();
    }
    jModifCedJur.setToolTipText("Sólo valores numéricos");

    jModifCodProve.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jModifCodProveKeyTyped(evt);
        }
    });

    jModifCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
        public void keyTyped(java.awt.event.KeyEvent evt) {
            jModifCodigoKeyTyped(evt);
        }
    });

    javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
    jPanel9.setLayout(jPanel9Layout);
    jPanel9Layout.setHorizontalGroup(
        jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel9Layout.createSequentialGroup()
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jSeparator32, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addComponent(jLabel17)
                            .addGap(37, 37, 37)
                            .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel9Layout.createSequentialGroup()
                                    .addGap(368, 368, 368)
                                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel22)
                                        .addComponent(jLabel29)
                                        .addComponent(jLabel25)
                                        .addComponent(jLabel23)
                                        .addComponent(jLabel24)
                                        .addComponent(jLabel27)))
                                .addGroup(jPanel9Layout.createSequentialGroup()
                                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jBotonBuscaMod, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel9Layout.createSequentialGroup()
                                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel9Layout.createSequentialGroup()
                                                    .addComponent(jLabel15)
                                                    .addGap(34, 34, 34))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                                    .addComponent(jLabel13)
                                                    .addGap(42, 42, 42)))
                                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(jModifNomProve, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)
                                                .addComponent(jModifCodProve))))
                                    .addGap(39, 39, 39)
                                    .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(18, 18, 18)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(jPanel9Layout.createSequentialGroup()
                                        .addComponent(jModifNom, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel26)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jModifApel, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jModifCategoria, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                                    .addComponent(jModifEmpresa, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                                    .addComponent(jModifTel)
                                    .addComponent(jModifCedJur))
                                .addComponent(jModifCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, 256, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(269, 269, 269)
                    .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addContainerGap(433, Short.MAX_VALUE))
    );
    jPanel9Layout.setVerticalGroup(
        jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel9Layout.createSequentialGroup()
            .addGap(46, 46, 46)
            .addComponent(jSeparator32, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(38, 38, 38)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(jModifCodProve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22)
                            .addComponent(jModifCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel15)
                        .addComponent(jModifNomProve, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jModifNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel26)
                                .addComponent(jModifApel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jModifCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel29, javax.swing.GroupLayout.Alignment.TRAILING))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel23)
                        .addComponent(jModifEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addGap(15, 15, 15)
                            .addComponent(jBotonBuscaMod, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel24)
                                .addComponent(jModifCedJur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel27)
                                .addComponent(jModifTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
            .addGap(31, 31, 31)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel17))
            .addGap(18, 18, 18)
            .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(102, Short.MAX_VALUE))
    );

    jLabel54.setFont(new java.awt.Font("Times New Roman", 3, 24)); // NOI18N
    jLabel54.setText("Modificación de Proveedores");

    javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
    jPanel3.setLayout(jPanel3Layout);
    jPanel3Layout.setHorizontalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel54, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap(943, Short.MAX_VALUE))
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
    );
    jPanel3Layout.setVerticalGroup(
        jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(jPanel3Layout.createSequentialGroup()
            .addContainerGap()
            .addComponent(jLabel54)
            .addContainerGap(626, Short.MAX_VALUE))
        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(95, Short.MAX_VALUE)))
    );

    jTabbedPane3.addTab("Modificar", jPanel3);
    jPanel3.getAccessibleContext().setAccessibleParent(TaPa1);

    TaPa1.addTab("Cartel de Proveedores", jTabbedPane3);

    getContentPane().add(TaPa1);
    TaPa1.setBounds(10, 90, 1160, 710);

    jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Screenshot_1.png"))); // NOI18N
    getContentPane().add(jLabel2);
    jLabel2.setBounds(1190, 70, 155, 173);

    lblBienvenido.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    lblBienvenido.setText("Bienvenido");
    getContentPane().add(lblBienvenido);
    lblBienvenido.setBounds(1190, 290, 61, 20);

    nombreUsuario.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
    nombreUsuario.setText("Usuario");
    getContentPane().add(nombreUsuario);
    nombreUsuario.setBounds(1290, 290, 43, 20);

    btnCerrarSesion.setText("Cerrar sesión ");
    btnCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnCerrarSesionActionPerformed(evt);
        }
    });
    getContentPane().add(btnCerrarSesion);
    btnCerrarSesion.setBounds(1190, 340, 148, 40);

    lblSan.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
    lblSan.setText("San Joaquín  de Flores ");
    getContentPane().add(lblSan);
    lblSan.setBounds(1190, 460, 140, 20);

    lblHeredia.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
    lblHeredia.setText("Heredia");
    getContentPane().add(lblHeredia);
    lblHeredia.setBounds(1240, 500, 46, 20);

    lbl2016.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
    lbl2016.setText("2016");
    getContentPane().add(lbl2016);
    lbl2016.setBounds(1250, 530, 28, 20);
    getContentPane().add(jSeparator1);
    jSeparator1.setBounds(1190, 440, 148, 20);
    getContentPane().add(jSeparator2);
    jSeparator2.setBounds(1190, 260, 146, 13);

    btnAyuda.setText("Ayuda");
    btnAyuda.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(java.awt.event.ActionEvent evt) {
            btnAyudaActionPerformed(evt);
        }
    });
    getContentPane().add(btnAyuda);
    btnAyuda.setBounds(1190, 400, 148, 30);

    lblSistemaBodega.setBackground(new java.awt.Color(255, 255, 255));
    lblSistemaBodega.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
    lblSistemaBodega.setForeground(new java.awt.Color(255, 255, 255));
    lblSistemaBodega.setText("Sistema de Bodega Municipalidad de Flores");
    getContentPane().add(lblSistemaBodega);
    lblSistemaBodega.setBounds(430, 50, 660, 36);

    lblMunicipalidad.setBackground(new java.awt.Color(255, 255, 255));
    lblMunicipalidad.setFont(new java.awt.Font("Times New Roman", 3, 36)); // NOI18N
    lblMunicipalidad.setForeground(new java.awt.Color(255, 255, 255));
    lblMunicipalidad.setText("Municipalidad de Flores");
    getContentPane().add(lblMunicipalidad);
    lblMunicipalidad.setBounds(580, 10, 410, 42);
    getContentPane().add(jSeparator4);
    jSeparator4.setBounds(1190, 320, 146, 20);

    jSeparator8.setForeground(new java.awt.Color(0, 51, 102));
    getContentPane().add(jSeparator8);
    jSeparator8.setBounds(10, 90, 1160, 20);

    jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/BG.jpg"))); // NOI18N
    jLabel30.setText("jLabel30");
    getContentPane().add(jLabel30);
    jLabel30.setBounds(0, 0, 1560, 820);

    jLabel1.setText("jLabel1");
    getContentPane().add(jLabel1);
    jLabel1.setBounds(230, 60, 34, 14);

    jLabel8.setText("jLabel8");
    getContentPane().add(jLabel8);
    jLabel8.setBounds(450, 40, 34, 14);

    jToggleButton1.setText("jToggleButton1");
    getContentPane().add(jToggleButton1);
    jToggleButton1.setBounds(310, 40, 105, 23);

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        // TODO add your handling code here:
        Point point = MouseInfo.getPointerInfo().getLocation() ; 
        setLocation(point.x - x, point.y - y)  ;
    }//GEN-LAST:event_formMouseDragged

    private void btnCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSesionActionPerformed
    new Login().setVisible(true);
        this.setVisible(false);       
    }//GEN-LAST:event_btnCerrarSesionActionPerformed

    private void btnAyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAyudaActionPerformed
    new Ayuda().setVisible(true);
        this.setVisible(true);    
        
// TODO add your handling code here:
    }//GEN-LAST:event_btnAyudaActionPerformed

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed

        if(campoJustificacionCrearSolicitud.getText().equals("")){JOptionPane.showMessageDialog(this, "Debe introducir una justificación");
        return;}
        
        
        else if(jTable3.getRowCount()==0){
        JOptionPane.showMessageDialog(this, "No ha introducido materiales");
        return;}
        
        else{
            
         int numero_solicitud=insertarSolicitud(campoJustificacionCrearSolicitud.getText());

        	for(int row = 0;row < modeloTablaCrearSolicitud.getRowCount();row++) {
String datos[]=new String[5];

	    for(int col = 0;col < modeloTablaCrearSolicitud.getColumnCount();col++) {

	        //System.out.println(modeloTablaCrearSolicitud.getValueAt(row, col));
                datos[col]=modeloTablaCrearSolicitud.getValueAt(row, col).toString();
                System.out.println(datos[col]);
               // JOptionPane.showMessageDialog(this,datos[col],"Error",JOptionPane.ERROR_MESSAGE);
	    }
enviarSolic(datos,numero_solicitud);
	}
        }
        codCrearSolicitud.setText("");
        jSpinner2.setValue(0);
        campoJustificacionCrearSolicitud.setText("");
        modeloTablaCrearSolicitud.setRowCount(0);
JOptionPane.showMessageDialog(this,"Solicitud creada");
llenarComboBox();
// TODO add your handling code here:
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void btnCargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargaActionPerformed

obtener_informacion_usuario();
boolean banderaRepetido=false;
String cod=codCrearSolicitud.getText();
String cant=jSpinner2.getValue().toString();
String tipo=obtenerTipo(cod);
String desc=ObtenerDescripcion(cod);
//String nSol=Integer.toString(num4);
String soli=datosUsuario[0];
String sql="SELECT id_material FROM material WHERE id_material="+cod;

try{
Statement sa = con.connect().createStatement();
ResultSet rsa = sa.executeQuery(sql);

if (!rsa.isBeforeFirst()) {  
    JOptionPane.showMessageDialog(this, "Material invalido");
    codCrearSolicitud.setText("");
    jSpinner2.setValue(0);
}

else if(cant.equals("0")){
JOptionPane.showMessageDialog(this, "Digite un numero mayor que cero");
    
}


else{
    
    //Modificacion
    for(int row = 0;row < modeloTablaCrearSolicitud.getRowCount();row++) {

if(cod.equals(modeloTablaCrearSolicitud.getValueAt(row, 0).toString())){

    int resultado=Integer.parseInt(cant)+ Integer.parseInt(modeloTablaCrearSolicitud.getValueAt(row,1).toString());
    modeloTablaCrearSolicitud.setValueAt(resultado,row,1);
    banderaRepetido=true;

}
	}
 
    if(!banderaRepetido){
modeloTablaCrearSolicitud.addRow(new Object[]{cod,cant,tipo,desc,soli});}
    
jTable3.setModel(modeloTablaCrearSolicitud);
 } 

}catch(SQLException e){
     JOptionPane.showMessageDialog(this, "Digite 7 caracteres numericos para el codigo");
System.out.println(sql); 
 System.out.println(e.getMessage());
}
   
// TODO add your handling code here:
    }//GEN-LAST:event_btnCargaActionPerformed

    private void jtxtApeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtApeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApeActionPerformed

    private void btnCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearActionPerformed
 int numero_orden = Integer.parseInt(jtxtOrden.getText());

insertarOrden(numero_orden);
enviarOrden(numero_orden);

JOptionPane.showMessageDialog(null, "Datos Ingresados correctamente");
limpiarOrdenCompra();

jTextField7.setEditable(true);
jtxtOrden.setEditable(true);
jtxtCode.setEditable(true);
jtxtPrecio.setEditable(true);


	
    }//GEN-LAST:event_btnCrearActionPerformed

    private void btnCargarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCargarActionPerformed
int precio = Integer.parseInt(jtxtPrecio.getText());
int cant = Integer.parseInt(jSpinner3.getValue().toString());
String codProveedor = jTextField7.getText();
int numeroOrden = Integer.parseInt(jtxtOrden.getText());
jtxtOrden.setEditable(false);
int codMaterial = Integer.parseInt(jtxtCode.getText());
int precioTotal = precio * cant;
String tipo = jComboBox5.getSelectedItem().toString();
String desc = jtxtDesc.getText();




modeloTablaCrearOrden.addRow(new Object[]{now(), codProveedor, cant, tipo, codMaterial, desc, numeroOrden, precio, precioTotal});
jTable1.setModel(modeloTablaCrearOrden);

totalOrden();

totalOrden=0;
    
    }//GEN-LAST:event_btnCargarActionPerformed

    private void jtxtLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtLastActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtLastActionPerformed

    private void jtxtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNameActionPerformed

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed

 int codOrden = 0;

    
    if(!jtxtOrdenCOmpre.getText().equals("")){
    codOrden= Integer.parseInt(jtxtOrdenCOmpre.getText());
    }else{
        codProve = 0;
    }

     try{  
     if(codOrden != 0){
        buscarOrden(codOrden);
        jtxtOrdenCOmpre.setText("");
        }
          
            else{
                JOptionPane.showMessageDialog(null, "Inserte un número de orden de compra válido");
            }
        
     }
     catch(Exception e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Error desconocido"); 
             }
     
totalOrdenBuscar();
totalOrdenBusca=0;
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnConsultarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultarActionPerformed
numAux.setVisible(false);
        numAux.setText(jtxtNumeroOrden.getText());
        //int codOrden = 0;

    
    if(!numAux.getText().equals("")){
    numOrden= Integer.parseInt(numAux.getText());
    }else{
        numOrden = 0;
    }

     try{  
     if(numOrden != 0){
         
        modifOrden(numOrden);
        jtxtNumeroOrden.setText("");
        }
          
            else{
                JOptionPane.showMessageDialog(null, "Inserte un número de orden de compra válido");
            }
        
     }
     catch(Exception e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Error desconocido"); 
             }
     
totalOrdenModif();
totalOrdenModif=0;
    }//GEN-LAST:event_btnConsultarActionPerformed

    private void jTextField8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField8ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField8ActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        numOrden = Integer.parseInt(numAux.getText());
        
       
        try {
            String sql="DELETE FROM detalle_orden WHERE numero_orden=" +numOrden;
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
            int n = us.executeUpdate();
            if(n>0){
                //JOptionPane.showMessageDialog(null, "Actualizando datos");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
               
        
        try {
            String sql="DELETE FROM orden_compra WHERE numero_orden=" +numOrden;
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
            int n = us.executeUpdate();
            
            if(n>0){
                //JOptionPane.showMessageDialog(null, "Actualizando datos");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        actualizarDetalleOrden();
        terminaActualizar();
        
       // jTable2.removeAll();
        jTable2.setEnabled(true);
        vaciarTabla2();
        
        numAux.setText("");
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void jTxtEmpresa01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxtEmpresa01ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTxtEmpresa01ActionPerformed
//BotonInsertar Proveedor
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         int codigoProve= Integer.parseInt(NProveedor01.getText());
    try{
           PreparedStatement us = cn.prepareStatement("INSERT INTO proveedores(empresa,ced_juridica,nombre_contacto,apel_contacto,telefono,direccion,codigo_proveedor,categoria) VALUES (?,?,?,?,?,?,?,?)");
          
 
            
            us.setString(1, jTxtEmpresa01.getText());
            us.setString(2, jtxtCedJ01.getText());
            us.setString(3, jtxtNombre01.getText());
            us.setString(4, jtxtApe01.getText());
            us.setString(5, jtxtTele01.getText());
            
            us.setString(6, jTextAreaDir.getText());  
            us.setInt(7, codigoProve);
            us.setString(8, jTextCategoria.getText());
            us.executeUpdate();
            //MostrarProveedor();  //Tabla retirada

            JOptionPane.showMessageDialog(null, "Datos Guardados");
            
    }  catch(SQLException | HeadlessException e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Datos Ingresados Incorrectamente");
        }
    
    LimpiarNuevoProveedor();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jtxtCedJ01ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCedJ01ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCedJ01ActionPerformed
//Boton Buscar Proveedores
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
   
    int codProve = 0;
    String nomProve = "";
    if(!jBuscaCodProve.getText().equals("")){
    codProve= Integer.parseInt(jBuscaCodProve.getText());
    }else{
        codProve = 0;
    }
    if(!jBuscaNomProve.getText().equals("")){
     nomProve = jBuscaNomProve.getText();
    }else{
     nomProve = "";
    }
    
     try{  
     if(codProve != 0 && nomProve.equals("")){
        buscarProveedor(codProve, "");
        jBuscaCodProve.setText("");
        }else{
            if(codProve == 0 && !nomProve.equals("")){
            buscarProveedor(0, nomProve);
            jBuscaNomProve.setText("");
            }else{
                JOptionPane.showMessageDialog(null, "Proveedor no encontrado");
            }
        }
     }
     catch(Exception e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Error desconocido"); 
             }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jModifNomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jModifNomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jModifNomActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        codProve = Integer.parseInt(jModifCodProve.getText());
        
       
        try {
            String sql="DELETE FROM proveedores WHERE codigo_proveedor=" +codProve;
            PreparedStatement us = con.connect().prepareStatement(sql);
            System.out.println(sql);
            int n = us.executeUpdate();
            if(n>0){
                JOptionPane.showMessageDialog(null, "Actualizando datos");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        actualizarProveedor();

    }//GEN-LAST:event_jButton8ActionPerformed

    private void jModifNomProveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jModifNomProveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jModifNomProveActionPerformed

    private void jBotonBuscaModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBotonBuscaModActionPerformed
        //Boton buscar Para modificar Proveedores

        int codModProve = 0;
        String nomModProve = "";

        if(!jModifCodProve.getText().equals("")){
            codModProve= Integer.parseInt(jModifCodProve.getText());
        }else{
            codModProve = 0;
        }
        if(!jModifNomProve.getText().equals("")){
            nomModProve = jModifNomProve.getText();
        }else{
            nomModProve = "";
        }

        try{
            if(codModProve != 0 && nomModProve.equals("")){
                modificaProveedor(codModProve, "");
                //jModifCodProve.setText("");
                //jModifNomProve.setText("");
                /*                jModifCodProve.setEditable(false);
                jModifNomProve.setEditable(false);*/
            }else{
                if(codModProve == 0 && !nomModProve.equals("")){
                    modificaProveedor(0, nomModProve);
                //jModifCodProve.setText("");
                //jModifNomProve.setText("");
                    /*                    jModifNomProve.setEditable(false);
                    jModifCodProve.setEditable(false);*/
                }else{
                    JOptionPane.showMessageDialog(null, "Proveedor no encontrado");
                }
            }
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(null, "Error desconocido");
        }
         
         
    }//GEN-LAST:event_jBotonBuscaModActionPerformed

    private void btnBuscaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscaActionPerformed

         modeloTablaModificarSolicitud.setRowCount(0);


String sqla="SELECT a.id_material,a.cantidad,b.nombre "
        + "FROM detalle_solicitud a, material b WHERE "
        + "a.numero_solicitud="+numSolicitudModificar.getText()+" AND b.id_material=a.id_material";        


try{
Statement sa = con.connect().createStatement();
ResultSet rsa = sa.executeQuery(sqla);

if (!rsa.isBeforeFirst() ) {  
    JOptionPane.showMessageDialog(this, "Numero de solicitud no encontrado");
    numSolicitudModificar.setText("");
} 
else if(numSolicitudModificar.getText().equals("")){JOptionPane.showMessageDialog(this, "No ha seleccionado ninguna solicitud");}
else{
numSoli=Integer.parseInt(numSolicitudModificar.getText());
while (rsa.next())
{
   // Se crea un array que será una de las filas de la tabla.
   Object [] fila = new Object[3]; 

   // Se rellena cada posición del array con una de las columnas de la tabla en base de datos.
   for (int i=0;i<3;i++)
      fila[i] = rsa.getObject(i+1); // El primer indice en rs es el 1, no el cero, por eso se suma 1.

   // Se añade al modelo la fila completa.
   modeloTablaModificarSolicitud.addRow(fila);
}

}

}
catch(SQLException e){
    //else if(modeloTablaModificarSolicitud.getRowCount()==0){JOptionPane.showMessageDialog(this, "No ha seleccionado ninguna solicitud");}
    JOptionPane.showMessageDialog(this, "Introduzca un numero de solicitud valido");
   System.out.println(sqla); 
 System.out.println(e.getMessage());
}        
jTable5.setModel(modeloTablaModificarSolicitud); 
        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscaActionPerformed

    private void btnEnviaCambioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviaCambioActionPerformed
int cantidad=0;

// System.out.println(sql);
 
if(modeloTablaModificarSolicitud.getRowCount()==0){JOptionPane.showMessageDialog(this, "No ha seleccionado ninguna solicitud");}
else{ 
    
    if(codAntiguo.getText().equals("")||codNuevo.getText().equals("")||cantidadNueva.getText().equals(""))
    {
        JOptionPane.showMessageDialog(this, "Debe rellenar todos los campos");
    }
    else{
        
    for(int row = 0;row < modeloTablaModificarSolicitud.getRowCount();row++) {

if(codAntiguo.getText().equals(modeloTablaModificarSolicitud.getValueAt(row, 0).toString())){

    
    
      if(codNuevo.getText().equals(modeloTablaModificarSolicitud.getValueAt(row, 0).toString())){
      
         modeloTablaModificarSolicitud.removeRow(row);
           modeloTablaModificarSolicitud.addRow(new Object[]{codNuevo.getText(),cantidadNueva.getText(),ObtenerDescripcion(codNuevo.getText())});
         
      
      }
      else{
       if(!validarCodigo(codNuevo.getText())){
       JOptionPane.showMessageDialog(this,"El código introducido no existe");
       return;
       }   
      modeloTablaModificarSolicitud.setValueAt(codNuevo.getText(),row,0);
     modeloTablaModificarSolicitud.setValueAt(cantidadNueva.getText(),row,1);
      modeloTablaModificarSolicitud.setValueAt(ObtenerDescripcion(codNuevo.getText()),row,2);
       
      }
    
      try{
        String sql="UPDATE detalle_solicitud SET id_material= "+codNuevo.getText()+", cantidad="+cantidadNueva.getText()
                +" WHERE id_material="+codAntiguo.getText()+" and numero_Solicitud="+numSoli;
        System.out.println(sql);
        PreparedStatement us = con.connect().prepareStatement(sql);
      us.executeUpdate();
      us.close();
      System.out.println("Exito");
      JOptionPane.showMessageDialog(this, "Modificacion exitosa");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql");
          JOptionPane.showMessageDialog(this, "El código para el nuevo material no existe");
          return;
        }


      
      
      
      
         return;

}
	}
    
    JOptionPane.showMessageDialog(this, "El codigo introducido no se encuentra en la solicitud");
    return;
    }

}
numSolicitudModificar.setText("");
modeloTablaModificarSolicitud.setRowCount(0);

// TODO add your handling code here:
    }//GEN-LAST:event_btnEnviaCambioActionPerformed

    
    private void jtxtCedJKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCedJKeyTyped
     
        String texto=jTxtEmpresa.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una empresa");
        }   
SoloNumeros(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCedJKeyTyped

    private void jtxtCedJ01KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCedJ01KeyTyped
String texto=jtxtDescrip.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Categoria");
        }   
           SoloNumeros(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCedJ01KeyTyped

    private void jtxtTele01KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtTele01KeyTyped
String texto=jtxtApe01.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Apellido");
        }   
           SoloNumeros(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTele01KeyTyped

    private void jtxtSolicitanteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtSolicitanteKeyTyped
        SoloLetras(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtSolicitanteKeyTyped

    private void jtxtSolicitanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtSolicitanteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtSolicitanteActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
      int codMaterial = 0;
    String nombMaterial = "";
    
    if(!jtxtCodigos2.getText().equals("")){
    codMaterial= Integer.parseInt(jtxtCodigos2.getText());
    }else{
        codMaterial = 0;
    }
    if(!jtxtDescription1.getText().equals("")){
     nombMaterial = jtxtDescription1.getText();
    }else{
     nombMaterial = "";
    }
        try{  
     if(codMaterial != 0 ){  //&& nombMaterial.equals("")
         buscaInventario(codMaterial,"");
        jtxtCodigos2.setText("");
        }else{
            if(codMaterial == 0 && !nombMaterial.equals("")){
                buscaInventario(0, nombMaterial);
            jtxtDescription1.setText("");
            }else{
                JOptionPane.showMessageDialog(null, "Material no encontrado");
            }
        }
     }
        catch(Exception e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Error desconocido"); 
             }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jComboBoxInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxInventarioActionPerformed

        Object item = jComboBoxInventario.getSelectedItem();
        String categ = String.valueOf(item);
        System.out.println(categ);
        limpiarTabla(tablaNuevoMaterial);
        setFilasInventarioSelected(categ);        // TODO add your handling code here:

    }//GEN-LAST:event_jComboBoxInventarioActionPerformed

    private void btnBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBusquedaActionPerformed


DefaultTableModel modelo = new DefaultTableModel(){

 public boolean isCellEditable(int row, int column)
 {
     return false;
 }
  };
modelo.addColumn("Código");
modelo.addColumn("Cantidad");
modelo.addColumn("Descripción");
modelo.addColumn("Tipo de unidad");
String sql="select b.id_material,b.cantidad,a.nombre,a.tipoUnidad "
        + "FROM material a, detalle_solicitud b where "
        + "b.numero_Solicitud="+campoConsultaSolicitud.getText()+" and b.id_material=a.id_material";
try{
Statement s = con.connect().createStatement();
ResultSet rs = s.executeQuery(sql);


if (!rs.isBeforeFirst() ) {  
    JOptionPane.showMessageDialog(this, "Numero de solicitud no encontrado");
    campoConsultaSolicitud.setText("");
   
} 

else{
while (rs.next())
{
   // Se crea un array que será una de las filas de la tabla.
   Object [] fila = new Object[4]; 

   // Se rellena cada posición del array con una de las columnas de la tabla en base de datos.
   for (int i=0;i<4;i++)
      fila[i] = rs.getObject(i+1); // El primer indice en rs es el 1, no el cero, por eso se suma 1.

   // Se añade al modelo la fila completa.
   modelo.addRow(fila);
}
}
}
catch(SQLException e){
   System.out.println(sql); 
 System.out.println(e.getMessage());
}        
jTable4.setModel(modelo);
        
// TODO add your handling code here:
    }//GEN-LAST:event_btnBusquedaActionPerformed

    private void jTable4KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTable4KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jTable4KeyTyped

    private void campoJustificacionCrearSolicitudKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoJustificacionCrearSolicitudKeyTyped
SoloLetras(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_campoJustificacionCrearSolicitudKeyTyped

    private void jSpinner2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jSpinner2KeyTyped
SoloNumeros(evt);
        // TODO add your handling code here:
    }//GEN-LAST:event_jSpinner2KeyTyped

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed

   int cantidad=0;
       int cantidadr=0;
       int cantidadRec=0;
         for(int row = 0;row < ESOrden_Compra.getRowCount();row++) {
             
             String valor=ESOrden_Compra.getValueAt(row,6).toString();
             
             if(!valor.equals("")){
              
              cantidad=Integer.parseInt(ESOrden_Compra.getValueAt(row,6).toString());
            // ESOrden_Compra.setValueAt(0, row, 6);
            // System.out.println(ESOrden_Compra.getValueAt(row,6));
             }else{
             cantidad=0;
             }
             
             //cantidad=Integer.parseInt(ESOrden_Compra.getValueAt(row,6).toString())+Integer.parseInt(ESOrden_Compra.getValueAt(row,3).toString());
             cantidadr=cantidad+Integer.parseInt(ESOrden_Compra.getValueAt(row,5).toString());
             cantidadRec=cantidad;
//ESOrden_Compra.setValueAt(cantidad, row, 3);
             ESOrden_Compra.setValueAt(cantidadr, row, 5);
             guardarESOrden(cantidadRec,cantidadr,ESOrden_Compra.getValueAt(row,0).toString(),jtxtOredesN.getText());
             //ESOrden_Compra.getValueAt(row,0).toString()
	        //System.out.println(modeloTablaCrearSolicitud.getValueAt(row, col));
                
                
               // JOptionPane.showMessageDialog(this,datos[col],"Error",JOptionPane.ERROR_MESSAGE);
	    }   
         jtxtOredesN.setText("");
         limpiarTabla(jTable11);    
// TODO add your handling code here:
    }//GEN-LAST:event_jButton18ActionPerformed

    private void btnDescontarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDescontarActionPerformed
                                           
int cantidad2=0;
float cantidad=0;
         for(int row = 0;row < EsSoli_M.getRowCount();row++) {
             cantidad=Float.parseFloat(EsSoli_M.getValueAt(row,3).toString());
             cantidad2=Math.round(cantidad);
             //EsSoli_M.setValueAt(cantidad, row, 3);
             guardarEsSoli_M(cantidad2,EsSoli_M.getValueAt(row,0).toString());
	      
	    }  limpiarTabla(jTable12);   
            llenarComboBox();
        // TODO add your handling code here:        // TODO add your handling code here:
    }//GEN-LAST:event_btnDescontarActionPerformed

    private void jtxtDeparKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDeparKeyTyped
SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDeparKeyTyped

    private void jtxtContKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtContKeyTyped
String texto=jtxtCedJ.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar Cedula Juridica");
        }   
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtContKeyTyped

    private void jtxtApeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApeKeyTyped

        String texto=jtxtCont.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un nombre de contacto");
        }   
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApeKeyTyped

    private void jtxtNameKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNameKeyTyped
SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNameKeyTyped

    private void jtxtLastKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtLastKeyTyped
SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtLastKeyTyped

    private void jTextCategoriaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextCategoriaKeyTyped
String texto=jTxtEmpresa01.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una Empresa");
        }   

SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jTextCategoriaKeyTyped

    private void jtxtNombre01KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNombre01KeyTyped
String texto=jtxtCedJ01.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Cedula juridica");
        }   
SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNombre01KeyTyped

    private void jtxtApe01KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApe01KeyTyped
String texto=jtxtNombre01.getText();
              texto=texto.replaceAll(" ", "");
           if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Nombre");
        }  
           SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApe01KeyTyped

    private void numSolicitudModificarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_numSolicitudModificarKeyTyped
  if(numSolicitudModificar.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);               // TODO add your handling code here:
    }//GEN-LAST:event_numSolicitudModificarKeyTyped

    private void campoConsultaSolicitudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoConsultaSolicitudActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_campoConsultaSolicitudActionPerformed

    private void campoConsultaSolicitudKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_campoConsultaSolicitudKeyTyped

         if( campoConsultaSolicitud.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);  
        // TODO add your handling code here:
    }//GEN-LAST:event_campoConsultaSolicitudKeyTyped

    private void jtxtCodeKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodeKeyTyped


        SoloNumeros(evt);
        char teclaPress = evt.getKeyChar();
        if(teclaPress==KeyEvent.VK_ENTER){
            int codMat = Integer.parseInt(jtxtCode.getText());
            mostrarMaterial(codMat);
        }
        
      if(jtxtCode.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        
    } 
    }//GEN-LAST:event_jtxtCodeKeyTyped

    private void jTextField7FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField7FocusLost
        int codProvee = Integer.parseInt(jTextField7.getText());
        mostrarProveedor(codProvee);
    }//GEN-LAST:event_jTextField7FocusLost

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jTextField7KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField7KeyTyped
                                   


        SoloNumeros(evt);
        char teclaPress = evt.getKeyChar();
        if(teclaPress==KeyEvent.VK_ENTER){
            int codProvee = Integer.parseInt(jTextField7.getText());
            mostrarProveedor(codProvee);
        }
        
if(jTextField7.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        
    }  
        

    }//GEN-LAST:event_jTextField7KeyTyped

    private void jComboBox7ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBox7ItemStateChanged

  EsSoli_M.setRowCount(0);
String sql="select b.id_material,a.tipoUnidad,a.nombre,b.cantidad, c.nombre_solic,c.depart_proceso, c.justificacion "
        + "FROM material a, detalle_solicitud b, solicitud_materiales c where "
        + "b.numero_Solicitud="+jComboBox7.getSelectedItem()+" and b.id_material=a.id_material"
        + " AND c.numero_Solicitud="+jComboBox7.getSelectedItem();
try{
Statement s = con.connect().createStatement();
ResultSet rs = s.executeQuery(sql);
 
 
while (rs.next()){
String ID=rs.getString("id_material");
String tipo=rs.getString("tipoUnidad");
String nombre=rs.getString("nombre");
String cantidad=rs.getString("cantidad");
//String solicitante=rs.getString("nombre_solic");
//String dpto=rs.getString("depart_proceso");
 
EsSoli_M.addRow(new Object[]{ID,tipo,nombre,cantidad});
 jtxtDepar.setText(rs.getString("depart_proceso"));
jtxtSolicitante.setText(rs.getString("nombre_solic"));
jTextArea1.setText(rs.getString("justificacion"));
 
}
 
}
catch(SQLException e){
   System.out.println(sql);
 System.out.println(e.getMessage());
}        
jTable12.setModel(EsSoli_M);       // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox7ItemStateChanged

    private void jComboBoxInventarioItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxInventarioItemStateChanged

        Object item = jComboBoxInventario.getSelectedItem();
        String categ = String.valueOf(item);
        System.out.println(categ);
        limpiarTabla(tablaNuevoMaterial);
        setFilasInventarioSelected(categ);
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxInventarioItemStateChanged

    private void jComboBoxInventarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jComboBoxInventarioFocusGained
      // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxInventarioFocusGained

    private void jComboBoxInventarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jComboBoxInventarioFocusLost
          // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxInventarioFocusLost

    private void jComboBoxInventarioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxInventarioKeyPressed
  
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxInventarioKeyPressed

    private void jtxtCodigos2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodigos2KeyTyped
if(jtxtCodigos2.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigos2KeyTyped
SoloNumeros(evt);
    }
    
    private void jtxtCodigos2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigos2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigos2ActionPerformed

    private void NProveedor01KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_NProveedor01KeyTyped
     if(NProveedor01.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);   // TODO add your handling code here:
    }//GEN-LAST:event_NProveedor01KeyTyped

    private void jBuscaCodProveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jBuscaCodProveKeyTyped
      if(jBuscaCodProve.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);    // TODO add your handling code here:
    }//GEN-LAST:event_jBuscaCodProveKeyTyped

    private void jModifCodProveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jModifCodProveKeyTyped
        if(jModifCodProve.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);  // TODO add your handling code here:
    }//GEN-LAST:event_jModifCodProveKeyTyped

    private void jModifCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jModifCodigoKeyTyped
      
    }//GEN-LAST:event_jModifCodigoKeyTyped

    private void codCrearSolicitudKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codCrearSolicitudKeyTyped
              if(codCrearSolicitud.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);  // TODO add your handling code here:
    }//GEN-LAST:event_codCrearSolicitudKeyTyped

    private void codAntiguoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codAntiguoKeyTyped
            if(codAntiguo.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);  // TODO add your handling code here:
    }//GEN-LAST:event_codAntiguoKeyTyped

    private void codNuevoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codNuevoKeyTyped
               if(codAntiguo.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);  // TODO add your handling code here:
    }//GEN-LAST:event_codNuevoKeyTyped

    private void cantidadNuevaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_cantidadNuevaKeyTyped
     SoloNumeros(evt);   // TODO add your handling code here:
    }//GEN-LAST:event_cantidadNuevaKeyTyped

    private void jtxtOrdenKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtOrdenKeyTyped
                if(jtxtOrden.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);    // TODO add your handling code here:
    }//GEN-LAST:event_jtxtOrdenKeyTyped

    private void jtxtPrecioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtPrecioKeyTyped
      SoloNumeros(evt); 
      
        if(jtxtPrecio.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        
    } 
    }//GEN-LAST:event_jtxtPrecioKeyTyped

    private void jtxtTotalesKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtTotalesKeyTyped
//     SoloNumeros(evt);     // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalesKeyTyped

    private void jtxtTotalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtTotalKeyTyped
      SoloNumeros(evt);  // TODO add your handling code here:
    }//GEN-LAST:event_jtxtTotalKeyTyped

    private void jtxtNumeroOrdenKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNumeroOrdenKeyTyped
      if(jtxtNumeroOrden.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);    // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNumeroOrdenKeyTyped

    private void jtxtCodgKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodgKeyTyped
     if(jtxtCodg.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);    // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodgKeyTyped

    private void jtxtCodgCKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodgCKeyTyped
    if(jtxtCodgC.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt);     // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodgCKeyTyped

    private void jtxtOrdenCOmpreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtOrdenCOmpreKeyTyped
       /*if(jtxtOrdenCOmpre.getText().length()<7){
 } else { 
         evt.setKeyChar('\0');        // TODO add your handling code here:
    }                                     
SoloNumeros(evt); */   // TODO add your handling code here:
    }//GEN-LAST:event_jtxtOrdenCOmpreKeyTyped

    private void btnCrearKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnCrearKeyTyped
       String texto2= jTextField7.getText();
        String texto=jTxtEmpresa.getText();
        String texto1= jtxtCedJ.getText(); 
        String texto4=jtxtCont.getText();
        String texto3= jtxtApe.getText(); 
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        texto3=texto3.replaceAll(" ", "");
        texto4= texto4.replaceAll("","");
        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0 || texto3.length()==0 || texto4.length()==0  ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCrearKeyTyped

    private void btnCargarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnCargarKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCargarKeyTyped

    private void btnGuardarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnGuardarKeyTyped
  String texto2= jtxtNumeroOrden.getText();
        String texto=jtxtCodg.getText();
        String texto1= jtxtNombre.getText(); 
        String texto3=jtxtApellido.getText();
        String texto4= jtxtCedula.getText(); 
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        texto3=texto3.replaceAll(" ", "");
        texto4= texto4.replaceAll("","");
        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0 || texto3.length()==0 || texto4.length()==0  ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
            // TODO add your handling code here:
    }//GEN-LAST:event_btnGuardarKeyTyped

    private void btnEnviarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnEnviarKeyTyped
         String texto2= codCrearSolicitud.getText();
        String texto=campoJustificacionCrearSolicitud.getText();
        texto=texto.replaceAll(" ", "");
        texto2=texto2.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        if(texto.length()==0  || texto2.length()==0  ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
       // TODO add your handling code here:
    }//GEN-LAST:event_btnEnviarKeyTyped

    private void jButton3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton3KeyTyped
 String texto2= jTxtEmpresa01.getText();
        String texto=jTextCategoria.getText();
        String texto1= jtxtCedJ01.getText();
        String texto3= jtxtNombre01.getText();
        String texto4=jtxtApe01.getText();
        String texto5= jtxtTele01.getText();
        String texto6=NProveedor01.getText();
        String texto7= jTextAreaDir.getText();
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        texto3=texto3.replaceAll(" ", "");
        texto4= texto4.replaceAll("","");
        texto5=texto5.replaceAll(" ", "");
        texto6= texto6.replaceAll("","");
        texto7=texto7.replaceAll(" ", "");
       
        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0  || texto3.length()==0 || texto4.length()==0 || texto5.length()==0 || texto6.length()==0 || texto7.length()==0 ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
           // TODO add your handling code here:
    }//GEN-LAST:event_jButton3KeyTyped

    private void jtxtCodeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtCodeFocusLost
        int codMaterial = Integer.parseInt(jtxtCode.getText());
        mostrarMaterial(codMaterial);
        jtxtTotales.setText("0");
    }//GEN-LAST:event_jtxtCodeFocusLost

    private void jTextTotActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextTotActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextTotActionPerformed

    private void jtxtCode1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jtxtCode1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCode1FocusLost

    private void jtxtCode1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCode1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCode1KeyTyped

    private void jtxtPrecio1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtPrecio1KeyTyped
       SoloNumeros(evt);  
    }//GEN-LAST:event_jtxtPrecio1KeyTyped

    private void jtxtCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigoActionPerformed

    private void jtxtCodigoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtCodigoKeyTyped
        SoloNumeros(evt);
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigoKeyTyped

    private void jtxtDescripActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDescripActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescripActionPerformed

    private void jtxtDescripKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDescripKeyTyped
        String texto=jtxtCodigo.getText();
        texto=texto.replaceAll("", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Codigo");
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescripKeyTyped

    private void jComboBoxCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaActionPerformed
        String texto=jtxtDescrip.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Nombre");
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaActionPerformed

    private void jComboBoxCategoriaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaKeyPressed

    private void jComboBoxCategoriaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaKeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaKeyTyped

    private void jTextCantMinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextCantMinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextCantMinActionPerformed

    private void jTextCantMinKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextCantMinKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextCantMinKeyPressed

    private void jTextCantMinKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextCantMinKeyTyped
        SoloNumeros(evt);

        // TODO add your handling code here:
    }//GEN-LAST:event_jTextCantMinKeyTyped

    private void jComboBoxTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoActionPerformed
        String texto=jTextCantMin.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una Cantidad Mínima");
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoActionPerformed

    private void jComboBoxTipoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxTipoKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoKeyPressed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed

        String texto2= jTextCantMin.getText();
        String texto=jtxtCodigo.getText();
        String texto1= jtxtDescrip.getText(); // revisar que esto este bien
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0  ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
        else
        {
            LlenarNuevoMaterial();
            LimpiarNuevoMaterial();
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jtxtCodigoMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigoMActionPerformed
        mostrarDatosActM();
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigoMActionPerformed

    private void jtxtDescripMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDescripMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescripMActionPerformed

    private void jtxtDescripMKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDescripMKeyTyped
        String texto=jtxtCodigoM.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Codigo");
        }                  // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescripMKeyTyped

    private void jComboBoxCategoriaMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaMActionPerformed

       // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaMActionPerformed

    private void jComboBoxCategoriaMKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaMKeyTyped
         // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaMKeyTyped

    private void jTextCantMinMKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextCantMinMKeyTyped
       
       SoloNumeros(evt);  
       String texto=jtxtDescripM.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Nombre");
        }  // TODO add your handling code here:
    }//GEN-LAST:event_jTextCantMinMKeyTyped

    private void jComboBoxTipoMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoMActionPerformed
            // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoMActionPerformed

    private void jtxtCodigosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtCodigosActionPerformed
        mostrarNombreM();
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtCodigosActionPerformed

    private void jSpinnerCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSpinnerCantidadActionPerformed
        ;
        // TODO add your handling code here:
    }//GEN-LAST:event_jSpinnerCantidadActionPerformed

    private void jSpinnerCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jSpinnerCantidadKeyTyped
        String texto=jtxtCodigos.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Codigo");
        }             // TODO add your handling code here:
        SoloNumeros(evt);
    }//GEN-LAST:event_jSpinnerCantidadKeyTyped

    private void jtxtDescriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDescriptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescriptionActionPerformed

    private void jtxtDescriptionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDescriptionKeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDescriptionKeyTyped

    private void jTexUbicacionRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTexUbicacionRegistroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTexUbicacionRegistroActionPerformed

    private void jTexUbicacionRegistroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTexUbicacionRegistroKeyTyped
        String texto= jSpinnerCantidad.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una Cantidad");
        }              // TODO add your handling code here:
    }//GEN-LAST:event_jTexUbicacionRegistroKeyTyped

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        String texto4=jTexUbicacionRegistro.getText();
        texto4=texto4.replaceAll(" ", "");
        if(texto4.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una Ubicación");
        }  else{
            String texto=jtxtCodigos.getText();
            String texto1=jSpinnerCantidad.getText(); // revisar que esto este bien
            String texto2= jTexUbicacionRegistro.getText();
            texto=texto.replaceAll(" ", "");
            texto1=texto1.replaceAll(" ", "");
            texto2=texto2.replaceAll("","");
            if(texto.length()==0 || texto1.length()==0 || texto2.length()==0 ){

                JOptionPane.showMessageDialog(null, "Se presenta un espacio en blanco,Complete los datos");

            }
            else
            {
                Registrar();
                LimpiarRegistroMaterial();
            }}

            // limpiarTabla(tablaNuevoMaterial);   ver que hacemos con este metodooo

            // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        int filas=0;
        limpiarTabla(jTable11);
        String Codigo="";
        String tipoUnidad="";
        String descripcion="";
        String cantidad="";
        String ubicacion="";
        String cantidad_reg="";
        String cantidad_rec="";
        String texto=jtxtOredesN.getText();
        texto=texto.replaceAll(" ", "");

        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Digite el Numero de Orden a Buscar ");
        }
        else
        {
            //JOptionPane.showMessageDialog(null, "ACA VA LA SENTENCIA DE SQL PARA BUSCAR");

            //cambios Moises
            String sql="SELECT b.id_material,a.tipoUnidad,a.nombre,b.cantidad,a.ubicacion,b.cantidad_registrada "
            + "FROM material a, detalle_orden b "
            + "WHERE b.id_material=a.id_material AND b.numero_orden="+jtxtOredesN.getText();

            try{
                Statement s = con.connect().createStatement();
                ResultSet rs = s.executeQuery(sql);

                if (rs.last()) {
                    filas = rs.getRow();
                    rs.beforeFirst();
                }

                while (rs.next())
                {
                    // Se crea un array que será una de las filas de la tabla.
                    Codigo=rs.getString("id_material");
                    tipoUnidad=rs.getString("tipoUnidad");
                    descripcion=rs.getString("nombre");
                    cantidad=rs.getString("cantidad");
                    ubicacion=rs.getString("ubicacion");
                    cantidad_reg=rs.getString("cantidad_registrada");

                    // Se rellena cada posición del array con una de las columnas de la tabla en base de datos.
                    //   for (int i=0;i<4;i++)
                    //      fila[i] = rs.getObject(i+1); // El primer indice en rs es el 1, no el cero, por eso se suma 1.

                    // Se añade al modelo la fila completa.
                    ESOrden_Compra.addRow(new Object[] {Codigo,tipoUnidad,descripcion,cantidad,ubicacion,cantidad_reg,cantidad_rec});
                }

            }
            catch(SQLException e){
                System.out.println(sql);
                System.out.println(e.getMessage());
            }

            jTable11.setModel(ESOrden_Compra);
            
            jTable11.getModel().addTableModelListener(new TableModelListener() {

            @Override
            public void tableChanged(TableModelEvent evento) {
                
                validaTabla(evento);
            }
        });
        }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jtxtNickKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtNickKeyTyped
        String texto=jtxtApel2.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un Apellido");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtNickKeyTyped

    private void btnCrearUsuario1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btnCrearUsuario1KeyTyped

        String texto2= jtxtUser3.getText();
        String texto=jtxtApel2.getText();
        String texto1= jtxtNick.getText();
        String texto3= jtxtContraseña2.getText();
        String texto4=jtxtRepetir2.getText();
        String texto5= jtxtDepa.getText();
        String texto6= jtxtDes2.getText();
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        texto3=texto3.replaceAll(" ", "");
        texto4=texto4.replaceAll(" ", "");
        texto5= texto5.replaceAll("","");
        texto6=texto6.replaceAll(" ", "");

        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0 || texto3.length()==0 || texto4.length()==0 || texto5.length()==0 || texto6.length()==0 ){

            JOptionPane.showMessageDialog(null, "complete los datos en blanco");
        }
        else
        {
            LlenarNuevoMaterial();
            LimpiarNuevoMaterial();
        }        // TODO add your handling code here:
    }//GEN-LAST:event_btnCrearUsuario1KeyTyped

    private void btnCrearUsuario1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearUsuario1ActionPerformed
        CrearUsuario();
    }//GEN-LAST:event_btnCrearUsuario1ActionPerformed

    private void jtxtDes2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDes2KeyTyped
        String texto=jtxtDepa.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un departamento");
        }           // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDes2KeyTyped

    private void jtxtDes2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDes2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDes2ActionPerformed

    private void jtxtDepaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtDepaKeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDepaKeyTyped

    private void jtxtDepaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtDepaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtDepaActionPerformed

    private void jtxtApel2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtApel2KeyTyped
        String texto=jtxtUser3.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un nombre");
        }   SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApel2KeyTyped

    private void jtxtApel2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtApel2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtApel2ActionPerformed

    private void jtxtRepetir2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtRepetir2KeyTyped
        String texto=jtxtContraseña2.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una contraseña");
        }         // TODO add your handling code here:
    }//GEN-LAST:event_jtxtRepetir2KeyTyped

    private void jtxtContraseña2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtContraseña2KeyTyped
        String texto=jtxtNick.getText();
        texto=texto.replaceAll(" ", "");
        if(texto.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar un NickName");
        }
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtContraseña2KeyTyped

    private void jtxtUser3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtUser3KeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtUser3KeyTyped

    private void jtxIDUSUActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxIDUSUActionPerformed
        busca();        // TODO add your handling code here:
    }//GEN-LAST:event_jtxIDUSUActionPerformed

    private void jtxtId3KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtId3KeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtxtId3KeyTyped

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        deshabilitarUsuario();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        habilitarUsuario();
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jtxtId2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtId2ActionPerformed

        buscaModificar();

        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtId2ActionPerformed

    private void jTextNombreModKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextNombreModKeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jTextNombreModKeyTyped

    private void jtstdepa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtstdepa2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtstdepa2ActionPerformed

    private void jtstdepa2KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtstdepa2KeyTyped
        SoloLetras(evt);          // TODO add your handling code here:
    }//GEN-LAST:event_jtstdepa2KeyTyped

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        actualizarUsuario();

        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
    String texto3=jTextCantMinM.getText();
        texto3=texto3.replaceAll(" ", "");
        if(texto3.length()==0){

            JOptionPane.showMessageDialog(null, "Se debe Ingresar una Cantidad Mínina");
        }  else{
        String texto2= jTextCantMinM.getText();
        String texto=jtxtCodigoM.getText();
        String texto1= jtxtDescripM.getText(); // revisar que esto este bien
        texto=texto.replaceAll(" ", "");
        texto1=texto1.replaceAll(" ", "");
        texto2= texto2.replaceAll("","");
        if(texto.length()==0 || texto1.length()==0 || texto2.length()==0  ){

            JOptionPane.showMessageDialog(null, "hay un espacio en blanco");
        }
        else
        {
            ActualizarNuevoMaterial();
            LimpiarActualizarMaterial();
        }}
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jComboBoxCategoriaMItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxCategoriaMItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxCategoriaMItemStateChanged

    private void codCrearSolicitudKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codCrearSolicitudKeyReleased

        if(codCrearSolicitud.getText().length()==7){

    try{
       
String sql="SELECT id_material FROM material WHERE id_material="+codCrearSolicitud.getText();      
Statement sa = con.connect().createStatement();
ResultSet rsa = sa.executeQuery(sql);

if (!rsa.isBeforeFirst()) {  
    JOptionPane.showMessageDialog(this, "Material invalido");
    codCrearSolicitud.setText("");
    //jSpinner2.setValue(0);
}
    
    
    }catch(SQLException e){
  System.out.println(e.getMessage());
}     
    
}        
        
// TODO add your handling code here:
    }//GEN-LAST:event_codCrearSolicitudKeyReleased

    private void codAntiguoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codAntiguoKeyReleased

         if(codAntiguo.getText().length()==7){

    try{
       
String sql="SELECT id_material FROM material WHERE id_material="+codAntiguo.getText();      
Statement sa = con.connect().createStatement();
ResultSet rsa = sa.executeQuery(sql);

if (!rsa.isBeforeFirst()) {  
    JOptionPane.showMessageDialog(this, "Material invalido");
    codAntiguo.setText("");
    //jSpinner2.setValue(0);
}
    
    
    }catch(SQLException e){
  System.out.println(e.getMessage());
}     
    
}        
        
// TODO add your handling code here:
    }//GEN-LAST:event_codAntiguoKeyReleased

    private void codNuevoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_codNuevoKeyReleased

         if(codNuevo.getText().length()==7){

    try{
       
String sql="SELECT id_material FROM material WHERE id_material="+codNuevo.getText();      
Statement sa = con.connect().createStatement();
ResultSet rsa = sa.executeQuery(sql);

if (!rsa.isBeforeFirst()) {  
    JOptionPane.showMessageDialog(this, "Material invalido");
    codNuevo.setText("");
    //jSpinner2.setValue(0);
}
    
    
    }catch(SQLException e){
  System.out.println(e.getMessage());
}     
    
}        
        // TODO add your handling code here:
    }//GEN-LAST:event_codNuevoKeyReleased

    private void codNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codNuevoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codNuevoActionPerformed

    private void jtxtOredesNKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtxtOredesNKeyTyped
                                    

        SoloNumeros(evt);  
        // TODO add your handling code here:
    }//GEN-LAST:event_jtxtOredesNKeyTyped

    private void numSolicitudModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_numSolicitudModificarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_numSolicitudModificarActionPerformed

    private void campoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_campoUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_campoUsuarioActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        jPopupMenu1.setLocation( evt.getLocationOnScreen());
        jPopupMenu1.setEnabled(true);
        jPopupMenu1.setVisible(true);
        
        
    }//GEN-LAST:event_jTable2MouseClicked

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        jPopupMenu1.setVisible(false);
        jPopupMenu1.setEnabled(false);
        int i  = jTable2.getSelectedRow();
         jTable2.setEnabled(false);
         
         int codMater = 0;
         codMater = Integer.parseInt((String) ModifOrden.getValueAt(i,3));
         jtxtCode1.setText((String) ModifOrden.getValueAt(i,3));
        jtxtPrecio1.setText((String) ModifOrden.getValueAt(i, 5));
        jSpinner4.setValue(Integer.parseInt((String) ModifOrden.getValueAt(i, 2)));
        String sql ="";
        if(codMater != 0){
            
          sql="SELECT nombre, tipoUnidad FROM material WHERE id_material = "+codMater+" ";
      
    }
 String []datos = new String [1];
        try {
            Statement st = cn.createStatement();

            ResultSet rs = st.executeQuery(sql);
           
            while(rs.next()){
                jtxtDesc1.setText(rs.getString(1));
                jtxtDesc1.setEditable(false);
                jComboBox8.setSelectedItem(rs.getString(2));
                jComboBox8.setEnabled(false);
  }
             } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
int precio = Integer.parseInt(jtxtPrecio1.getText());
int cant = Integer.parseInt(jSpinner4.getValue().toString());
String codProveedor = jtxtCodg.getText();
int numeroOrden = Integer.parseInt(numAux.getText());

int codMaterial = Integer.parseInt(jtxtCode1.getText());
int precioTotal = precio * cant;


jtxtPrecio1.setText("");
jtxtDesc1.setText("");
jtxtCode1.setText("");




ModifOrden.addRow(new Object[]{now(), codProveedor, cant, codMaterial, numeroOrden, precio, precioTotal});

jTable2.setModel(ModifOrden);
        
        int i  = jTable2.getSelectedRow();
        ModifOrden.removeRow(i);
        jTable2.setEnabled(true);
        
        
        totalOrdenModif();
        totalOrdenModif = 0;
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TaP2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TaP2MouseClicked
       numAux.setVisible(false);
    }//GEN-LAST:event_TaP2MouseClicked

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        int i = jTable2.getSelectedRow();
        ModifOrden.removeRow(i);
        jTable2.setModel(ModifOrden);
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jtxtPrecio1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtPrecio1ActionPerformed
              // TODO add your handling code here:
    }//GEN-LAST:event_jtxtPrecio1ActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
               UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");   
                               new Principal().setVisible(true);
                } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException ex) {
                    Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                }
     
               
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField NProveedor01;
    private javax.swing.JPanel Pan10;
    private javax.swing.JPanel Pan11;
    private javax.swing.JPanel Pan12;
    private javax.swing.JPanel Pan14;
    private javax.swing.JPanel Pan16;
    private javax.swing.JPanel Pan17;
    private javax.swing.JPanel Pan18;
    private javax.swing.JPanel Pan19;
    private javax.swing.JPanel Pan20;
    private javax.swing.JPanel Pan21;
    private javax.swing.JPanel Pan22;
    private javax.swing.JPanel Pan24;
    private javax.swing.JPanel Pan25;
    private javax.swing.JPanel Pan3;
    private javax.swing.JPanel Pan6;
    private javax.swing.JPanel Pan7;
    private javax.swing.JPanel Pan8;
    private javax.swing.JTabbedPane TaP2;
    public javax.swing.JTabbedPane TaPa1;
    private javax.swing.JTabbedPane TadP3;
    private javax.swing.JTabbedPane TadP5;
    private javax.swing.JTabbedPane TadP6;
    private javax.swing.JTabbedPane TadP7;
    private javax.swing.JButton btnAyuda;
    private javax.swing.JButton btnBusca;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnBusqueda;
    private javax.swing.JButton btnCarga;
    private javax.swing.JButton btnCargar;
    private javax.swing.JButton btnCerrarSesion;
    private javax.swing.JButton btnConsultar;
    private javax.swing.JButton btnCrear;
    private javax.swing.JButton btnCrearUsuario1;
    private javax.swing.JButton btnDescontar;
    private javax.swing.JButton btnEnviaCambio;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JButton btnMuestra;
    private javax.swing.JButton btnMuestras;
    private javax.swing.JTextField campoConsultaSolicitud;
    private javax.swing.JTextArea campoJustificacionCrearSolicitud;
    public javax.swing.JTextField campoUsuario;
    private javax.swing.JTextField cantidadNueva;
    private javax.swing.JTextField codAntiguo;
    private javax.swing.JTextField codCrearSolicitud;
    private javax.swing.JTextField codNuevo;
    private javax.swing.JButton jBotonBuscaMod;
    private javax.swing.JTextField jBuscaCodProve;
    private javax.swing.JTextField jBuscaNomProve;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox jCBoxTipoUsua;
    private javax.swing.JComboBox jComboBox13;
    private javax.swing.JComboBox jComboBox5;
    private javax.swing.JComboBox jComboBox6;
    private javax.swing.JComboBox jComboBox7;
    private javax.swing.JComboBox jComboBox8;
    private javax.swing.JComboBox jComboBoxCategoria;
    private javax.swing.JComboBox jComboBoxCategoriaM;
    private javax.swing.JComboBox jComboBoxInventario;
    private javax.swing.JComboBox jComboBoxTipo;
    private javax.swing.JComboBox jComboBoxTipoM;
    private javax.swing.JTextArea jDirecProveModif;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel560;
    private javax.swing.JLabel jLabel562;
    private javax.swing.JLabel jLabel563;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabela10;
    private javax.swing.JLabel jLabela15;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JTextField jModifApel;
    private javax.swing.JTextField jModifCategoria;
    private javax.swing.JFormattedTextField jModifCedJur;
    private javax.swing.JTextField jModifCodProve;
    private javax.swing.JTextField jModifCodigo;
    private javax.swing.JTextField jModifEmpresa;
    private javax.swing.JTextField jModifNom;
    private javax.swing.JTextField jModifNomProve;
    private javax.swing.JFormattedTextField jModifTel;
    private javax.swing.JPanel jPan19;
    public javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel16;
    public javax.swing.JPanel jPanel2;
    public javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel3;
    public javax.swing.JPanel jPanel5;
    public javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane26;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator12;
    private javax.swing.JSeparator jSeparator13;
    private javax.swing.JSeparator jSeparator14;
    private javax.swing.JSeparator jSeparator17;
    private javax.swing.JSeparator jSeparator18;
    private javax.swing.JSeparator jSeparator19;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator20;
    private javax.swing.JSeparator jSeparator21;
    private javax.swing.JSeparator jSeparator22;
    private javax.swing.JSeparator jSeparator23;
    private javax.swing.JSeparator jSeparator24;
    private javax.swing.JSeparator jSeparator25;
    private javax.swing.JSeparator jSeparator26;
    private javax.swing.JSeparator jSeparator27;
    private javax.swing.JSeparator jSeparator28;
    private javax.swing.JSeparator jSeparator29;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator30;
    private javax.swing.JSeparator jSeparator31;
    private javax.swing.JSeparator jSeparator32;
    private javax.swing.JSeparator jSeparator33;
    private javax.swing.JSeparator jSeparator340;
    private javax.swing.JSeparator jSeparator356;
    private javax.swing.JSeparator jSeparator357;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JSpinner jSpinner2;
    private javax.swing.JSpinner jSpinner3;
    private javax.swing.JSpinner jSpinner4;
    private javax.swing.JTextField jSpinnerCantidad;
    private javax.swing.JTabbedPane jTaPa9;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable11;
    private javax.swing.JTable jTable12;
    private javax.swing.JTable jTable15;
    private javax.swing.JTable jTable16;
    private javax.swing.JTable jTable17;
    private javax.swing.JTable jTable18;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable21;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JTable jTableOrden;
    private javax.swing.JTextField jTexUbicacionRegistro;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextArea jTextAreaDir;
    private javax.swing.JTextField jTextCantMin;
    private javax.swing.JTextField jTextCantMinM;
    private javax.swing.JTextField jTextCategoria;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextNombreMod;
    private javax.swing.JTextField jTextTot;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTextField jTxtEmpresa;
    private javax.swing.JTextField jTxtEmpresa01;
    private javax.swing.JFormattedTextField jtstdepa2;
    private javax.swing.JFormattedTextField jtxIDUSU;
    private javax.swing.JFormattedTextField jtxtApe;
    private javax.swing.JTextField jtxtApe01;
    private javax.swing.JFormattedTextField jtxtApel2;
    private javax.swing.JTextField jtxtApellido;
    private javax.swing.JFormattedTextField jtxtCed;
    private javax.swing.JFormattedTextField jtxtCedJ;
    private javax.swing.JFormattedTextField jtxtCedJ01;
    private javax.swing.JFormattedTextField jtxtCedula;
    private javax.swing.JTextField jtxtCode;
    private javax.swing.JTextField jtxtCode1;
    private javax.swing.JTextField jtxtCodg;
    private javax.swing.JTextField jtxtCodgC;
    private javax.swing.JFormattedTextField jtxtCodigo;
    private javax.swing.JFormattedTextField jtxtCodigoM;
    private javax.swing.JFormattedTextField jtxtCodigos;
    private javax.swing.JTextField jtxtCodigos2;
    private javax.swing.JTextField jtxtCont;
    private javax.swing.JPasswordField jtxtContraseña2;
    private javax.swing.JPasswordField jtxtContraseña3;
    private javax.swing.JFormattedTextField jtxtDepa;
    private javax.swing.JFormattedTextField jtxtDepar;
    private javax.swing.JFormattedTextField jtxtDes2;
    private javax.swing.JFormattedTextField jtxtDesc;
    private javax.swing.JTextField jtxtDesc1;
    private javax.swing.JFormattedTextField jtxtDescrip;
    private javax.swing.JFormattedTextField jtxtDescripM;
    private javax.swing.JFormattedTextField jtxtDescription;
    private javax.swing.JTextField jtxtDescription1;
    private javax.swing.JTextArea jtxtDirecProveBuscar;
    private javax.swing.JFormattedTextField jtxtId2;
    private javax.swing.JFormattedTextField jtxtId3;
    private javax.swing.JFormattedTextField jtxtLast;
    private javax.swing.JFormattedTextField jtxtName;
    private javax.swing.JFormattedTextField jtxtNick;
    private javax.swing.JTextField jtxtNombre;
    private javax.swing.JTextField jtxtNombre01;
    private javax.swing.JTextField jtxtNumeroOrden;
    private javax.swing.JTextField jtxtOrden;
    private javax.swing.JTextField jtxtOrdenCOmpre;
    private javax.swing.JTextField jtxtOredesN;
    private javax.swing.JTextField jtxtPrecio;
    private javax.swing.JTextField jtxtPrecio1;
    private javax.swing.JPasswordField jtxtRepetir2;
    private javax.swing.JFormattedTextField jtxtSolicitante;
    private javax.swing.JFormattedTextField jtxtTele01;
    private javax.swing.JTextField jtxtTotal;
    private javax.swing.JTextField jtxtTotales;
    private javax.swing.JFormattedTextField jtxtUser3;
    private javax.swing.JFormattedTextField jtxtUser4;
    private javax.swing.JLabel lbl2016;
    private javax.swing.JLabel lblApe;
    private javax.swing.JLabel lblApellidos;
    private javax.swing.JLabel lblBienvenido;
    private javax.swing.JLabel lblCant;
    private javax.swing.JLabel lblCant1;
    private javax.swing.JLabel lblCanti;
    private javax.swing.JLabel lblCategorias1;
    private javax.swing.JLabel lblCategorias2;
    private javax.swing.JLabel lblCed;
    private javax.swing.JLabel lblCedJu;
    private javax.swing.JLabel lblCedJu01;
    private javax.swing.JLabel lblCedJuri;
    private javax.swing.JLabel lblCod1;
    private javax.swing.JLabel lblCod2;
    private javax.swing.JLabel lblCode;
    private javax.swing.JLabel lblCode1;
    private javax.swing.JLabel lblCodes;
    private javax.swing.JLabel lblCodigos;
    private javax.swing.JLabel lblCon;
    private javax.swing.JLabel lblContact;
    private javax.swing.JLabel lblContacto;
    private javax.swing.JLabel lblContacto01;
    private javax.swing.JLabel lblContraseña2;
    private javax.swing.JLabel lblContraseña3;
    private javax.swing.JLabel lblD;
    private javax.swing.JLabel lblDe;
    private javax.swing.JLabel lblDepar;
    private javax.swing.JLabel lblDes;
    private javax.swing.JLabel lblDes1;
    private javax.swing.JLabel lblDescr1;
    private javax.swing.JLabel lblDescr2;
    private javax.swing.JLabel lblDescri2;
    private javax.swing.JLabel lblDescripcion;
    private javax.swing.JLabel lblDirection01;
    private javax.swing.JLabel lblEstate;
    private javax.swing.JLabel lblFiltro1;
    private javax.swing.JLabel lblHeredia;
    private javax.swing.JLabel lblId2;
    private javax.swing.JLabel lblId3;
    private javax.swing.JLabel lblJusticificacion;
    private javax.swing.JLabel lblLastName2;
    private javax.swing.JLabel lblMunicipalidad;
    private javax.swing.JLabel lblNames;
    private javax.swing.JLabel lblNames01;
    private javax.swing.JLabel lblNom;
    private javax.swing.JLabel lblNombres;
    private javax.swing.JLabel lblNum;
    private javax.swing.JLabel lblNumCompra;
    private javax.swing.JLabel lblNumOrde;
    private javax.swing.JLabel lblNumero;
    private javax.swing.JLabel lblOrdenCompra;
    private javax.swing.JLabel lblPro;
    private javax.swing.JLabel lblProductos;
    private javax.swing.JLabel lblProductos1;
    private javax.swing.JLabel lblProveedor;
    private javax.swing.JLabel lblProveedores;
    private javax.swing.JLabel lblPuesto2;
    private javax.swing.JLabel lblPuesto3;
    private javax.swing.JLabel lblRepetir2;
    private javax.swing.JLabel lblSan;
    private javax.swing.JLabel lblSeleccionar;
    private javax.swing.JLabel lblSistemaBodega;
    private javax.swing.JLabel lblSolicitante;
    private javax.swing.JLabel lblSolicitudes;
    private javax.swing.JLabel lblTel01;
    private javax.swing.JLabel lblTipos2;
    private javax.swing.JLabel lblTiposU;
    private javax.swing.JLabel lblTiposU1;
    private javax.swing.JLabel lblTotalOr;
    private javax.swing.JLabel lblTotalOrde;
    private javax.swing.JLabel lblTotalOrdenes;
    private javax.swing.JLabel lblUbicaciones;
    private javax.swing.JLabel lblUnitario;
    private javax.swing.JLabel lblUnitario1;
    private javax.swing.JLabel lblUser3;
    private javax.swing.JLabel lblUser4;
    private javax.swing.JLabel lblUser5;
    private javax.swing.JLabel lblUserName1;
    private javax.swing.JLabel lblUsers1;
    private javax.swing.JLabel nombreUsuario;
    private javax.swing.JTextField numAux;
    private javax.swing.JTextField numSolicitudModificar;
    private javax.swing.JTable tablaNuevoMaterial;
    // End of variables declaration//GEN-END:variables
       private void mostrarProveedor(int codigoProve) {
        String sql="";

            sql="SELECT * FROM proveedores WHERE codigo_proveedor='"+codigoProve+"'";

    
    String []datos = new String [5];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
              

                jTextField7.setText(datos[0]=rs.getString(8));
                jTxtEmpresa.setText(datos[1]=rs.getString(1));
                jTxtEmpresa.setEditable(false);
                jtxtCedJ.setText(datos[2]=rs.getString(2));
                jtxtCedJ.setEditable(false);
                jtxtCont.setText(datos[3]=rs.getString(3));
                jtxtCont.setEditable(false);
                jtxtApe.setText(datos[4]=rs.getString(4));
                jtxtApe.setEditable(false);

                
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    private void mostrarMaterial(int codMater) {
        String sql="";

            sql="SELECT * FROM material WHERE id_material='"+codMater+"'";

    
    String []datos = new String [3];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
              

                jtxtCode.setText(datos[0]=rs.getString(1));
                
                jComboBox5.setSelectedItem(datos[1]=rs.getString(4));
                jComboBox5.setEnabled(false);
                jtxtDesc.setText(datos[2]=rs.getString(2));
                jtxtDesc.setEditable(false);

            }
           
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }   }

    
    
    
private void enviarOrden( int n_o) {
        
         float cantidad;  //Float.parseFloat(datos[2]);
        int idMaterial; //Integer.parseInt(datos[4]);
        float precioUnit;  //Float.parseFloat(datos[7]);
        float precioTotal;
//"Fecha","Codigo Proveedor","Cantidad","Tipo de Unidad","Codigo Material","Descripcion","Número Orden","Precio unitario ¢","Precio Total ¢"};

        try{
        for(int i = 0; i<jTable1.getRowCount(); i++){
        PreparedStatement us = cn.prepareStatement("INSERT INTO detalle_orden(numero_orden, cantidad,id_material, precio_unit,precio_total)values(?,?,?,?,?)");
        cantidad = Float.parseFloat(jTable1.getValueAt(i, 2).toString());
        idMaterial = Integer.parseInt(jTable1.getValueAt(i, 4).toString());
        precioUnit = Float.parseFloat(jTable1.getValueAt(i, 7).toString());
        precioTotal = Float.parseFloat(jTable1.getValueAt(i, 8).toString());
        us.setInt(1,n_o);
        us.setFloat(2, cantidad);
        us.setInt(3,idMaterial);
        us.setFloat(4, precioUnit);
        us.setFloat(5, precioTotal);
        
        us.executeUpdate();
        }
      //System.out.println(sql);
      System.out.println("Datos Guardados");
        }
        catch(SQLException e)
        { System.out.println("Error Mysql Enviar Orden");
        //System.out.println(sql);
        
        }    
        }

private int insertarOrden(int numero_orden ) {
int num=0;
String estado = "Pendiente";
String date = now();


//"Fecha","Codigo Proveedor","Cantidad","Tipo de Unidad","Codigo Material","Descripcion","Número Orden","Precio unitario ¢","Precio Total ¢"};
   try{
       for(int i = 0; i<jTable1.getRowCount(); i++){
        int codigoProveedor = Integer.parseInt(jTable1.getValueAt(i, 1).toString() );
           PreparedStatement us = cn.prepareStatement("INSERT INTO orden_compra (numero_orden, estado, codigo_proveedor, fecha_entrega) VALUES (?,?,?,?)");
        
       us.setInt(1, numero_orden);
       us.setString(2, estado);
       us.setInt(3, codigoProveedor);
       us.setString(4, date.toString());
        
        us.executeUpdate();

 }
   }
catch(SQLException e){ 
    System.out.println("Error Mysql insertarOrden");
    //System.out.println(sql);
}
    
    return num;  
    }

    private void limpiarOrdenCompra() {
        jTextField7.setText("");
        jTxtEmpresa.setText("");
        jtxtCedJ.setText("");
        jtxtCont.setText("");
        jtxtApe.setText("");
        jtxtOrden.setText("");
        jtxtCode.setText("");
        jSpinner3.setValue(0);
        jtxtDesc.setText("");
        jtxtPrecio.setText("");
        jTable1.setModel(modeloTablaCrearOrden);
        jtxtTotales.setText("");
        for (int i = 0; i < jTable1.getRowCount(); i++) {
           modeloTablaCrearOrden.removeRow(i);
           i-=1;
        }
    }

    private void buscarOrden(int codOrden) {
        
      // "Fecha","Codigo Proveedor","Cantidad","Tipo de Unidad","Codigo Material","Descripcion","Número Orden","Precio unitario ¢","Precio Total ¢" 
    DefaultTableModel buscaOrden= new DefaultTableModel();
    
    buscaOrden.addColumn("Fecha");
    buscaOrden.addColumn("Cod. Proveedor");
    buscaOrden.addColumn("Cantidad");
    //buscaOrden.addColumn("Tipo de unidad");
    buscaOrden.addColumn("Cod. Material");
    //buscaOrden.addColumn("Descripción");
    buscaOrden.addColumn("Número Orden");
    buscaOrden.addColumn("Precio Unitario");
    buscaOrden.addColumn("Precio Total");
    buscaOrden.addColumn("Estado");
    
    jTableOrden.setModel(buscaOrden);
    
    String sql="";
   // String sql2 ="";
    String codMaterial ="";
    String codProve ="";
    //String descripcion="";
   
    
    

       if(codOrden != 0){
            
          sql="SELECT o.fecha_entrega, o.codigo_proveedor, d.cantidad, d.id_material, d.numero_orden, d.precio_unit, d.precio_total, o.estado  FROM detalle_orden d, orden_compra o WHERE d.numero_orden="+codOrden+" AND d.numero_orden = o.numero_orden ";
            
            
    }
    
    String []datos = new String [8];
        try {
            Statement st = cn.createStatement();

            ResultSet rs = st.executeQuery(sql);
           
            while(rs.next()){
              
            
           
               datos[0]=rs.getString(1);//fecha
                
                codProve= rs.getString(2);
                datos[1]= codProve;//codigo prveedor
                datos[2]=rs.getString(3);//cantidad
                codMaterial = rs.getString(4);
                muestraProveOrden(codProve);
                
                //datos[3]=tipoMaterial;//tipo material  jalar de la otra base de datos
                datos[3]=codMaterial;//Codigo material
                
                
                //datos[4]=descripcion;//descripcion jalar de la otra base de datos
                datos[4]=rs.getString(5);//numero orden
                datos[5]=rs.getString(6);//precio unitario
                datos[6]=rs.getString(7);//precio totalOrden
                datos[7]=rs.getString(8);//estado
                        
                buscaOrden.addRow(datos);
                
            }

            jTableOrden.setModel(buscaOrden);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    private void muestraProveOrden(String codProve) {
        int codigoProve = Integer.parseInt(codProve);
        String sql ="";
        if(codigoProve != 0){
            
          sql="SELECT nombre_contacto, apel_contacto, ced_juridica FROM proveedores WHERE codigo_proveedor = "+codigoProve+" ";
            
            
    }
    
    String []datos = new String [8];
        try {
            Statement st = cn.createStatement();

            ResultSet rs = st.executeQuery(sql);
           
            while(rs.next()){
                jtxtName.setText(rs.getString(1));
                jtxtLast.setText(rs.getString(2));
                jtxtCed.setText(rs.getString(3));
                jtxtCodgC.setText(codProve);
  }
             } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

   private void totalOrden(){
       //int totalOrden; 
       for(int i = 0; i<jTable1.getRowCount(); i++){
            int temp = Integer.parseInt(jTable1.getValueAt(i, 8).toString() );
            //int aux ;
            totalOrden += temp;
            
        }
       jtxtTotales.setText(String.valueOf(totalOrden));
    }
       
   private void totalOrdenBuscar(){
       //int totalOrden; 
       for(int i = 0; i<jTableOrden.getRowCount(); i++){
            int temp = Integer.parseInt(jTableOrden.getValueAt(i, 6).toString() );
            //int aux ;
            totalOrdenBusca = totalOrdenBusca + temp;
            
        }
       jTextTot.setText(String.valueOf(totalOrdenBusca));
    }

    private void totalOrdenModif() {
       for(int i = 0; i<jTable2.getRowCount(); i++){
            int temp = Integer.parseInt(jTable2.getValueAt(i, 6).toString() );
            //int aux ;
            totalOrdenModif = totalOrdenModif + temp;
            
        }
       jtxtTotal.setText(String.valueOf(totalOrdenModif));    }

    private void modifOrden(int codOrden) {
        /*  DefaultTableModel buscaOrden= new DefaultTableModel();
        
        buscaOrden.addColumn("Fecha");
        buscaOrden.addColumn("Cod. Proveedor");
        buscaOrden.addColumn("Cantidad");
        //buscaOrden.addColumn("Tipo de unidad");
        buscaOrden.addColumn("Cod. Material");
        //buscaOrden.addColumn("Descripción");
        buscaOrden.addColumn("Número Orden");
        buscaOrden.addColumn("Precio Unitario");
        buscaOrden.addColumn("Precio Total");
        //buscaOrden.addColumn("Estado");
        */
    jTable2.setModel(ModifOrden);
       for (int i = 0; i < jTable2.getRowCount(); i++) {
           ModifOrden.removeRow(i);
           i-=1;
       }
    String sql="";
   // String sql2 ="";
    String codMaterial ="";
    String codProve ="";
    //String descripcion="";
   
    
    

       if(codOrden != 0){
            
          sql="SELECT o.fecha_entrega, o.codigo_proveedor, d.cantidad, d.id_material, d.numero_orden, d.precio_unit, d.precio_total, o.estado  FROM detalle_orden d, orden_compra o WHERE d.numero_orden="+codOrden+" AND d.numero_orden = o.numero_orden ";
            
            
    }
    
    String []datos = new String [7];
        try {
            Statement st = cn.createStatement();

            ResultSet rs = st.executeQuery(sql);
           
            while(rs.next()){
              
            
           
               datos[0]=rs.getString(1);//fecha
                
                codProve= rs.getString(2);
                datos[1]= codProve;//codigo prveedor
                datos[2]=rs.getString(3);//cantidad
                codMaterial = rs.getString(4);
                muestraProveModif(codProve);
                
                //datos[3]=tipoMaterial;//tipo material  jalar de la otra base de datos
                datos[3]=codMaterial;//Codigo material
                
                
                //datos[4]=descripcion;//descripcion jalar de la otra base de datos
                datos[4]=rs.getString(5);//numero orden
                datos[5]=rs.getString(6);//precio unitario
                datos[6]=rs.getString(7);//precio totalOrden
                //datos[7]=rs.getString(8);//estado
                jComboBox6.setSelectedItem(rs.getString(8));
                        
                ModifOrden.addRow(datos);
                
            }

            jTable2.setModel(ModifOrden);
        } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }
       }

    private void muestraProveModif(String codProve) {
int codigoProve = Integer.parseInt(codProve);
        String sql ="";
        if(codigoProve != 0){
            
          sql="SELECT nombre_contacto, apel_contacto, ced_juridica FROM proveedores WHERE codigo_proveedor = "+codigoProve+" ";
            
            
    }
    
    String []datos = new String [8];
        try {
            Statement st = cn.createStatement();

            ResultSet rs = st.executeQuery(sql);
           
            while(rs.next()){
                jtxtNombre.setText(rs.getString(1));
                jtxtNombre.setEditable(false);
                jtxtApellido.setText(rs.getString(2));
                jtxtApellido.setEditable(false);
                jtxtCedula.setText(rs.getString(3));
                jtxtCedula.setEditable(false);
                jtxtCodg.setText(codProve);
                jtxtCodg.setEditable(false);
                
  }
             } catch (SQLException ex) {
            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
        }  }

    private void actualizarDetalleOrden() {
                 float cantidad;  //Float.parseFloat(datos[2]);
        int idMaterial; //Integer.parseInt(datos[4]);
        float precioUnit;  //Float.parseFloat(datos[7]);
        float precioTotal;
numOrden= Integer.parseInt(numAux.getText());
       
      // us = cn.prepareStatement("DELETE * from proveedores WHERE codigo_proveedor=" +codigo);
    try{
        //PreparedStatement us = cn.prepareStatement("INSERT INTO detalle_orden(numero_orden,cantidad,id_material,precio_unit,precio_total) VALUES (?,?,?,?,?)");
 for(int i = 0; i<jTable2.getRowCount(); i++){
        PreparedStatement us = cn.prepareStatement("INSERT INTO detalle_orden(numero_orden, cantidad,id_material, precio_unit,precio_total)values(?,?,?,?,?)");
        cantidad = Float.parseFloat(jTable2.getValueAt(i, 2).toString());
        idMaterial = Integer.parseInt(jTable2.getValueAt(i, 3).toString());
        precioUnit = Float.parseFloat(jTable2.getValueAt(i, 5).toString());
        precioTotal = Float.parseFloat(jTable2.getValueAt(i, 6).toString());
        us.setInt(1,numOrden);
        us.setFloat(2, cantidad);
        us.setInt(3,idMaterial);
        us.setFloat(4, precioUnit);
        us.setFloat(5, precioTotal);
        
        us.executeUpdate();

        }
            

            //JOptionPane.showMessageDialog(null, "Datos Guardados");
            
    }  catch(SQLException | HeadlessException e){
        System.out.println(e.getMessage());
        JOptionPane.showMessageDialog(null, "Datos Ingresados Incorrectamente");
        }  
        //actualizarOrden();
        //terminaActualizar();
    
    }

    /*    private void actualizarOrden() {
    try {
    String sql="DELETE FROM orden_compra WHERE numero_orden=" +numOrden;
    PreparedStatement us = con.connect().prepareStatement(sql);
    System.out.println(sql);
    int n = us.executeUpdate();
    
    if(n>0){
    JOptionPane.showMessageDialog(null, "Actualizando datos");
    }
    
    } catch (SQLException ex) {
    Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
    }
    }*/
//terminaActualizar();
    

    private int terminaActualizar() {
        numOrden= Integer.parseInt(numAux.getText());
int num=0;
String estado = (String) jComboBox6.getSelectedItem();
String date = now();


//"Fecha","Codigo Proveedor","Cantidad","Tipo de Unidad","Codigo Material","Descripcion","Número Orden","Precio unitario ¢","Precio Total ¢"};
   try{
       for(int i = 0; i<jTable2.getRowCount(); i++){
        int codigoProveedor = Integer.parseInt(jtxtCodg.getText() );
           PreparedStatement us = cn.prepareStatement("INSERT INTO orden_compra (numero_orden, estado, codigo_proveedor, fecha_entrega) VALUES (?,?,?,?)");
        
       us.setInt(1, numOrden);
       us.setString(2, estado);
       us.setInt(3, codigoProveedor);
       us.setString(4, date);
        System.out.println(us);
       int n = us.executeUpdate();
                    if(n>0){
                JOptionPane.showMessageDialog(null, "Listo");
            }
                    /*        for(int e = 0; e<jTable1.getRowCount(); e++){
                    ModifOrden.removeRow(e);
                    jTable1.setModel(ModifOrden);
                    }*/
 }
   }
catch(SQLException e){ 
    System.out.println("Error Mysql insertarOrden");
    //System.out.println(sql);
}

    return num; 
  }
    private void vaciarTabla2(){
         for(int e = 0; e<jTable2.getRowCount(); e++){
                    ModifOrden.removeRow(e);
                    jTable2.setModel(ModifOrden);
                    }
    }
}
